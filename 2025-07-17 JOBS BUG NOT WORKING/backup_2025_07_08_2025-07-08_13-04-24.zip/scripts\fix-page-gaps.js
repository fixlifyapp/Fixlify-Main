// Script to fix the space-y-6 gap issue on all pages

const fs = require('fs');
const path = require('path');

const pagesDir = 'C:\\Users\\petru\\Downloads\\TEST FIX SITE\\3\\Fixlify-Main-main\\src\\pages';

// Pages to fix (those that use PageHeader)
const pagesToFix = [
  'AnalyticsPage.tsx',
  'AutomationsPage.tsx',
  'ClientsPage.tsx',
  'FinancePage.tsx',
  'JobsPageOptimized.tsx',
  'SchedulePage.tsx',
  'TeamManagementPage.tsx',
  'SettingsPage.tsx',
  'ConnectCenterPageOptimized.tsx',
  'TasksPage.tsx',
  'ReportsPage.tsx',
  'DocumentsPage.tsx',
  'EstimatesPage.tsx',
  'InvoicesPage.tsx',
  'InventoryPage.tsx',
  'ProductsPage.tsx',
  'IntegrationsPage.tsx',
  'ConfigurationPage.tsx',
  'PhoneNumbersPage.tsx',
  'AdminRolesPage.tsx'
];

pagesToFix.forEach(fileName => {
  const filePath = path.join(pagesDir, fileName);
  
  try {
    let content = fs.readFileSync(filePath, 'utf8');
    
    // Fix pattern 1: space-y-6 wrapper around PageHeader
    content = content.replace(
      /<div className={[`"]['"].*?space-y-\d+.*?[`"]['"]}>[\s\S]*?<PageHeader/g,
      (match) => {
        // Remove space-y-X from the wrapper div
        const fixed = match.replace(/space-y-\d+\s*/g, '');
        console.log(`Fixed space-y in ${fileName}`);
        return fixed;
      }
    );
    
    // Fix pattern 2: Add margin-bottom to elements after PageHeader if needed
    content = content.replace(
      /(<PageHeader[\s\S]*?\/>\s*)([\s\S]*?)(<div|<[A-Z])/g,
      (match, pageHeader, between, nextElement) => {
        // If the next element doesn't have margin, add mb-6
        if (!between.includes('mb-') && nextElement.startsWith('<div')) {
          console.log(`Added margin after PageHeader in ${fileName}`);
          return pageHeader + between + nextElement.replace('<div', '<div className="mb-6"');
        }
        return match;
      }
    );
    
    fs.writeFileSync(filePath, content);
    console.log(`✓ Fixed ${fileName}`);
  } catch (error) {
    console.error(`✗ Error fixing ${fileName}:`, error.message);
  }
});

console.log('\nDone! Check the pages to ensure the gap is fixed.');
