// Комплексная диагностика проблем
// Запустите в консоли браузера

console.log('🔍 Начинаем диагностику...\n');

// 1. Проверка проблемы с навигацией к клиенту
async function diagnoseClientNavigation() {
  console.log('📋 1. Диагностика навигации к клиенту:');
  
  // Проверяем текущий URL
  console.log('Текущий URL:', window.location.pathname);
  
  // Если мы на странице клиента
  if (window.location.pathname.includes('/clients/')) {
    const clientId = window.location.pathname.split('/clients/')[1];
    console.log('Client ID из URL:', clientId);
    
    // Проверяем, есть ли такой клиент
    try {
      const response = await fetch(`https://mqppvcrlvsgrsqelglod.supabase.co/rest/v1/clients?id=eq.${clientId}`, {
        headers: {
          'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1xcHB2Y3JsdnNncnNxZWxnbG9kIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDc1OTE3MDUsImV4cCI6MjA2MzE2NzcwNX0.My-KiqG1bCMqzUru4m59d4v18N3WGxNoNtFPOFAmhzg',
          'Authorization': `Bearer ${localStorage.getItem('fixlify-auth-token')?.replace(/['"]/g, '')}`
        }
      });
      
      const clients = await response.json();
      if (clients.length > 0) {
        console.log('✅ Клиент найден:', clients[0]);
      } else {
        console.log('❌ Клиент не найден в базе данных');
      }
    } catch (error) {
      console.error('❌ Ошибка проверки клиента:', error);
    }
  }
  
  // Получаем список всех клиентов
  try {
    const response = await fetch('https://mqppvcrlvsgrsqelglod.supabase.co/rest/v1/clients?select=id,name,email&limit=5', {
      headers: {
        'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1xcHB2Y3JsdnNncnNxZWxnbG9kIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDc1OTE3MDUsImV4cCI6MjA2MzE2NzcwNX0.My-KiqG1bCMqzUru4m59d4v18N3WGxNoNtFPOFAmhzg',
        'Authorization': `Bearer ${localStorage.getItem('fixlify-auth-token')?.replace(/['"]/g, '')}`
      }
    });
    
    const clients = await response.json();
    console.log(`\n📋 Найдено ${clients.length} клиентов:`);
    clients.forEach(client => {
      console.log(`- ${client.name} (ID: ${client.id})`);
    });
  } catch (error) {
    console.error('❌ Ошибка получения клиентов:', error);
  }
}

// 2. Проверка отправки Estimate/Invoice
async function diagnoseSendFunctions() {
  console.log('\n📧 2. Диагностика отправки Estimate/Invoice:');
  
  // Проверяем доступность функций
  const functions = ['send-estimate', 'send-invoice', 'send-email'];
  
  for (const func of functions) {
    try {
      const response = await fetch(`https://mqppvcrlvsgrsqelglod.supabase.co/functions/v1/${func}`, {
        method: 'OPTIONS',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('fixlify-auth-token')?.replace(/['"]/g, '')}`
        }
      });
      
      if (response.ok || response.status === 405) {
        console.log(`✅ Функция ${func} доступна`);
      } else {
        console.log(`❌ Функция ${func} недоступна (статус: ${response.status})`);
      }
    } catch (error) {
      console.error(`❌ Ошибка проверки ${func}:`, error);
    }
  }
}

// 3. Проверка конфигурации email
async function checkEmailConfig() {
  console.log('\n📬 3. Проверка конфигурации email:');
  
  // Проверяем наличие Mailgun домена
  try {
    const response = await fetch('https://mqppvcrlvsgrsqelglod.supabase.co/functions/v1/manage-mailgun-domains', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('fixlify-auth-token')?.replace(/['"]/g, '')}`
      },
      body: JSON.stringify({ action: 'list' })
    });
    
    if (response.ok) {
      const data = await response.json();
      console.log('Mailgun домены:', data);
    } else {
      console.log('❌ Не удалось получить список доменов Mailgun');
    }
  } catch (error) {
    console.error('❌ Ошибка проверки Mailgun:', error);
  }
}

// 4. Быстрые исправления
function quickFixes() {
  console.log('\n🔧 Быстрые исправления:');
  console.log('1. Обновите страницу: location.reload()');
  console.log('2. Очистите кэш: Ctrl+Shift+Delete');
  console.log('3. Проверьте консоль на ошибки');
  console.log('4. Убедитесь, что вы авторизованы');
}

// Запуск всех проверок
async function runFullDiagnostics() {
  await diagnoseClientNavigation();
  await diagnoseSendFunctions();
  await checkEmailConfig();
  quickFixes();
}

console.log('🛠️ Команды диагностики:');
console.log('- runFullDiagnostics() - запустить полную диагностику');
console.log('- diagnoseClientNavigation() - проверить навигацию');
console.log('- diagnoseSendFunctions() - проверить отправку');
console.log('- checkEmailConfig() - проверить email конфигурацию');

// Автоматически запускаем диагностику
runFullDiagnostics();
