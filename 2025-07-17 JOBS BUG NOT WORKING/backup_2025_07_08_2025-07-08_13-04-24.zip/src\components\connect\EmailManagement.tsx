
import { SimpleEmailInterface } from './components/SimpleEmailInterface';

export const EmailManagement = () => {
  return (
    <div className="h-full">
      <SimpleEmailInterface />
    </div>
  );
};
