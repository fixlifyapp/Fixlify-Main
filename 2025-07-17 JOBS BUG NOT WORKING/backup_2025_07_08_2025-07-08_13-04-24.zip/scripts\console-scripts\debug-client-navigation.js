// Диагностика проблемы с навигацией к клиенту
// Запустите в консоли браузера на странице с клиентами

// 1. Проверка данных клиентов
async function checkClientsData() {
  console.log('🔍 Проверка данных клиентов...\n');
  
  try {
    // Получаем клиентов из базы
    const response = await fetch('https://mqppvcrlvsgrsqelglod.supabase.co/rest/v1/clients?select=*&limit=5', {
      headers: {
        'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1xcHB2Y3JsdnNncnNxZWxnbG9kIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDc1OTE3MDUsImV4cCI6MjA2MzE2NzcwNX0.My-KiqG1bCMqzUru4m59d4v18N3WGxNoNtFPOFAmhzg',
        'Authorization': `Bearer ${localStorage.getItem('fixlify-auth-token')?.replace(/['"]/g, '')}`
      }
    });
    
    const clients = await response.json();
    console.log('📋 Найдено клиентов:', clients.length);
    
    if (clients.length > 0) {
      console.log('\nПервые клиенты:');
      clients.forEach(client => {
        console.log(`- ID: ${client.id}, Name: ${client.name}, Email: ${client.email}`);
      });
      
      // Проверяем URL для первого клиента
      const firstClient = clients[0];
      console.log(`\n🔗 URL для первого клиента: /clients/${firstClient.id}`);
      console.log('Структура первого клиента:', firstClient);
    }
  } catch (error) {
    console.error('❌ Ошибка получения клиентов:', error);
  }
}

// 2. Проверка текущего URL
function checkCurrentURL() {
  console.log('\n📍 Текущий URL:', window.location.pathname);
  const match = window.location.pathname.match(/\/clients\/(.+)/);
  if (match) {
    console.log('Client ID из URL:', match[1]);
  }
}

// 3. Проверка параметров маршрута
function checkRouteParams() {
  // Проверяем React Router
  const params = new URLSearchParams(window.location.search);
  console.log('\n🔍 Query параметры:', Object.fromEntries(params));
}

// 4. Тест навигации
function testNavigation(clientId) {
  console.log(`\n🚀 Тестовая навигация к клиенту ${clientId}`);
  window.location.href = `/clients/${clientId}`;
}

console.log('🛠️ Функции диагностики загружены!');
console.log('Команды:');
console.log('- checkClientsData() - проверить данные клиентов');
console.log('- checkCurrentURL() - проверить текущий URL');
console.log('- checkRouteParams() - проверить параметры');
console.log('- testNavigation("client-id") - тест навигации');

// Автоматически проверяем данные
checkClientsData();
checkCurrentURL();
