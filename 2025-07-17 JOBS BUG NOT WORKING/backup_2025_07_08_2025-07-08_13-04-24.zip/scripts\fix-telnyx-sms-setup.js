// Fix Telnyx SMS Setup Script
// This script will help you configure Telnyx SMS properly

console.log(`
===========================================
TELNYX SMS SETUP FIX
===========================================

The SMS system is not working because:

1. MISSING TELNYX API KEY
   - The TELNYX_API_KEY is not set in Supabase Edge Function secrets
   
2. NO ACTIVE PHONE NUMBERS WITH USER ASSIGNMENT
   - Phone numbers exist but aren't properly assigned to users
   
3. MISSING MESSAGING PROFILE ID (Optional)
   - The TELNYX_MESSAGING_PROFILE_ID is not configured

===========================================
STEP 1: GET YOUR TELNYX API KEY
===========================================

1. Go to https://portal.telnyx.com
2. Log in to your account
3. Navigate to API Keys section
4. Create a new API key or copy an existing one
5. Save this key - you'll need it in the next step

===========================================
STEP 2: SET TELNYX SECRETS IN SUPABASE
===========================================

1. Go to your Supabase Dashboard:
   https://supabase.com/dashboard/project/mqppvcrlvsgrsqelglod/functions/secrets

2. Add these secrets:
   - TELNYX_API_KEY = [Your Telnyx API Key from Step 1]
   - TELNYX_MESSAGING_PROFILE_ID = [Optional - Your messaging profile ID]
   - TELNYX_PHONE_NUMBER = [Optional - Default from number like +14375290279]

3. Click "Save" to apply the changes

===========================================
STEP 3: ASSIGN PHONE NUMBERS TO USERS
===========================================

Run this SQL in your Supabase SQL Editor to assign available phone numbers:
`);

const assignPhoneSQL = `
-- First, check your user ID
SELECT id, email FROM auth.users WHERE email = 'YOUR_EMAIL@example.com';

-- Then assign a phone number to your user
-- Replace 'YOUR_USER_ID' with the ID from the query above
UPDATE telnyx_phone_numbers 
SET 
  user_id = 'YOUR_USER_ID',
  status = 'active',
  updated_at = now()
WHERE phone_number = '+12898192158'  -- This number is already assigned to user 6dfbdcae-c484-45aa-9327-763500213f24
RETURNING *;

-- Or assign one of the available numbers:
-- +14375290279 or +14375248832
UPDATE telnyx_phone_numbers 
SET 
  user_id = 'YOUR_USER_ID',
  status = 'active',
  updated_at = now()
WHERE phone_number IN ('+14375290279', '+14375248832')
AND user_id IS NULL
LIMIT 1
RETURNING *;
`;

console.log(assignPhoneSQL);

console.log(`
===========================================
STEP 4: TEST THE SMS SYSTEM
===========================================

After completing the above steps:

1. Restart your Supabase Edge Functions (may take a few minutes to pick up new secrets)
2. Try sending an SMS from:
   - Estimates page: Click on any estimate > Actions > Send SMS
   - Invoices page: Click on any invoice > Actions > Send SMS
   - Messaging Center: Compose a new message and select SMS

===========================================
QUICK TEST SCRIPT
===========================================

You can test if Telnyx is configured by running this in your browser console:
`);

const testScript = `
// Test Telnyx connection
async function testTelnyxConnection() {
  try {
    const response = await fetch('https://mqppvcrlvsgrsqelglod.supabase.co/functions/v1/check-telnyx-key', {
      headers: {
        'Authorization': 'Bearer ' + (await supabase.auth.getSession()).data.session?.access_token,
        'Content-Type': 'application/json'
      }
    });
    
    const result = await response.json();
    console.log('Telnyx Connection Test:', result);
    
    if (result.success) {
      console.log('✅ Telnyx API Key is configured correctly!');
      console.log('📱 Available phone numbers:', result.availableNumbers);
    } else {
      console.error('❌ Telnyx configuration issue:', result.error);
    }
  } catch (error) {
    console.error('❌ Failed to test Telnyx:', error);
  }
}

// Run the test
testTelnyxConnection();
`;

console.log(testScript);

console.log(`
===========================================
ALTERNATIVE: USE TEST MODE
===========================================

If you don't have a Telnyx account yet, the system will work in "simulation mode":
- SMS messages will be logged but not actually sent
- You'll see success messages in the UI
- All SMS logs will be stored in the database

To get a Telnyx account:
1. Visit https://telnyx.com
2. Sign up for a free account
3. Purchase a phone number (starting at $1/month)
4. Follow the steps above to configure

===========================================
NEED HELP?
===========================================

If you're still having issues:
1. Check the Edge Function logs in Supabase Dashboard
2. Verify your Telnyx account has SMS enabled
3. Ensure your phone number has SMS capabilities
4. Check that your Telnyx account has credit

Current Status:
- You have 3 phone numbers in the database
- One is assigned to user 6dfbdcae-c484-45aa-9327-763500213f24
- Two are available for assignment
- No Telnyx API key is configured in Supabase
`);
