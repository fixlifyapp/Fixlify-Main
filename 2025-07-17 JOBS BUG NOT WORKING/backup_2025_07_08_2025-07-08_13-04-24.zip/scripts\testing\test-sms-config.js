// Test SMS Configuration
// Run this to check if everything is set up correctly

async function testSMSConfig() {
  const { supabase } = window;
  
  console.log('🔍 Testing SMS Configuration...\n');
  
  // Check auth
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) {
    console.error('❌ Not authenticated');
    return;
  }
  
  console.log('✅ Authenticated as:', user.email);
  console.log('👤 User ID:', user.id);
  
  // Check phone numbers
  const { data: phones } = await supabase
    .from('telnyx_phone_numbers')
    .select('*')
    .eq('user_id', user.id);
    
  if (phones && phones.length > 0) {
    console.log('\n✅ User has phone number(s):');
    phones.forEach(p => {
      console.log(`  📱 ${p.phone_number} (${p.status})`);
    });
  } else {
    console.log('\n⚠️ No phone numbers assigned to this user');
  }
  
  // Test SMS send
  console.log('\n📤 Testing SMS send...');
  const testPhone = prompt('Enter a phone number to test SMS (format: +1234567890):');
  
  if (!testPhone) {
    console.log('❌ Test cancelled');
    return;
  }
  
  try {
    const { data, error } = await supabase.functions.invoke('telnyx-sms', {
      body: {
        recipientPhone: testPhone,
        message: 'Test SMS from Fixlify - If you receive this, SMS is working correctly!',
        user_id: user.id,
        metadata: { test: true, timestamp: new Date().toISOString() }
      }
    });
    
    console.log('\n📬 Response:', { data, error });
    
    if (error) {
      console.error('❌ Error:', error.message);
      
      if (error.message.includes('API_KEY')) {
        console.log('💡 TELNYX_API_KEY needs to be set in Supabase Edge Functions > Secrets');
      } else if (error.message.includes('phone numbers')) {
        console.log('💡 No active phone numbers available');
      }
    } else if (data?.success) {
      console.log('✅ SMS sent successfully!');
      console.log('📱 From:', data.from);
      console.log('📱 To:', data.to);
      console.log('🆔 Message ID:', data.messageId);
    } else {
      console.error('❌ SMS failed:', data?.error || 'Unknown error');
    }
    
    // Check communication logs
    console.log('\n📋 Checking communication logs...');
    const { data: logs } = await supabase
      .from('communication_logs')
      .select('*')
      .eq('communication_type', 'sms')
      .eq('recipient', testPhone)
      .order('created_at', { ascending: false })
      .limit(1);
      
    if (logs && logs.length > 0) {
      console.log('✅ SMS logged in database:', logs[0]);
    }
    
  } catch (err) {
    console.error('❌ Unexpected error:', err);
  }
  
  console.log('\n📝 Summary:');
  console.log('- Edge functions are deployed ✅');
  console.log('- Phone number is assigned ✅');
  console.log('- Next: Check if TELNYX_API_KEY is set in Supabase');
  console.log('- Dashboard: https://supabase.com/dashboard/project/mqppvcrlvsgrsqelglod/functions/secrets');
}

// Run the test
testSMSConfig();