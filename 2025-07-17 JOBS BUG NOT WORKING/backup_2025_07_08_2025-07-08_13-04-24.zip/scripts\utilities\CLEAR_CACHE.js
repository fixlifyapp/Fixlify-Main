// Simple cache clear - paste this in browser console
localStorage.clear();
console.log('✅ Cache cleared! Refreshing page...');
location.reload();