
import { TelnyxCallsList } from "./TelnyxCallsList";

export const CallsList = () => {
  return <TelnyxCallsList />;
};
