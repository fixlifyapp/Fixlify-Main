// Fix Phone Numbers - Make some available to claim
// This script will add available numbers and fix existing ones

console.log('🔧 Fixing phone numbers in your system...\n');

async function fixPhoneNumbers() {
  try {
    const authToken = localStorage.getItem('fixlify-auth-token')?.replace(/['"]/g, '');
    if (!authToken) {
      console.error('❌ Please log in to Fixlify first!');
      return;
    }
    
    // Get current user
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      console.error('❌ Could not get user information');
      return;
    }
    
    console.log('✅ Logged in as:', user.email);
    console.log('👤 User ID:', user.id);
    console.log('');
    
    // Step 1: Release some numbers to make them available
    console.log('📱 Step 1: Making some numbers available to claim...\n');
    
    // Get all numbers
    const { data: allNumbers } = await supabase
      .from('telnyx_phone_numbers')
      .select('*')
      .order('phone_number');
    
    console.log(`Found ${allNumbers.length} total numbers in system`);
    
    // Keep first number for user, make others available
    if (allNumbers.length > 1) {
      for (let i = 1; i < allNumbers.length; i++) {
        const number = allNumbers[i];
        console.log(`Making ${number.phone_number} available...`);
        
        const { error } = await supabase
          .from('telnyx_phone_numbers')
          .update({ 
            user_id: null,
            status: 'available'
          })
          .eq('id', number.id);
          
        if (!error) {
          console.log(`✅ ${number.phone_number} is now available to claim`);
        }
      }
    }
    
    // Step 2: Add some test numbers as available
    console.log('\n📱 Step 2: Adding test numbers as available...\n');
    
    const testNumbers = [
      { number: '+14165551234', area: '416', city: 'Toronto' },
      { number: '+16475552345', area: '647', city: 'Toronto' },
      { number: '+19055553456', area: '905', city: 'Mississauga' }
    ];
    
    for (const testNum of testNumbers) {
      // Check if exists
      const { data: existing } = await supabase
        .from('telnyx_phone_numbers')
        .select('id')
        .eq('phone_number', testNum.number)
        .single();
      
      if (existing) {
        // Update to available
        const { error } = await supabase
          .from('telnyx_phone_numbers')
          .update({ 
            user_id: null,
            status: 'available'
          })
          .eq('id', existing.id);
          
        if (!error) {
          console.log(`📝 Updated ${testNum.number} to available`);
        }
      } else {
        // Insert new
        const { error } = await supabase
          .from('telnyx_phone_numbers')
          .insert({
            phone_number: testNum.number,
            status: 'available',
            country_code: 'US',
            area_code: testNum.area,
            locality: testNum.city,
            monthly_cost: 0,
            setup_cost: 0,
            purchased_at: new Date().toISOString()
          });
          
        if (!error) {
          console.log(`✅ Added ${testNum.number} as available`);
        }
      }
    }
    
    // Step 3: Show final status
    console.log('\n📊 Final Status:\n');
    
    const { data: finalNumbers } = await supabase
      .from('telnyx_phone_numbers')
      .select('*')
      .order('phone_number');
    
    const yourNumbers = finalNumbers.filter(n => n.user_id === user.id);
    const availableNumbers = finalNumbers.filter(n => !n.user_id);
    
    console.log(`✅ Your numbers: ${yourNumbers.length}`);
    yourNumbers.forEach(n => {
      console.log(`   📞 ${n.phone_number}`);
    });
    
    console.log(`\n📱 Available to claim: ${availableNumbers.length}`);
    availableNumbers.forEach(n => {
      console.log(`   📞 ${n.phone_number} (${n.locality || n.area_code || 'Available'})`);
    });
    
    console.log('\n🎉 Done! Refreshing page to show changes...');
    
    // Refresh the page
    setTimeout(() => {
      window.location.reload();
    }, 2000);
    
  } catch (error) {
    console.error('❌ Error:', error);
  }
}

// Run the fix
fixPhoneNumbers();
