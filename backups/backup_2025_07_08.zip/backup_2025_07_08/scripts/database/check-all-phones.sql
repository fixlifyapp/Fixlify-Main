-- Simple check of all phone numbers
SELECT * FROM telnyx_phone_numbers ORDER BY created_at DESC;