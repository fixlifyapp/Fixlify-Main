// Paste this in the browser console to debug the layout

console.log('=== Layout Debug ===');

// Find all elements between header and main content
const header = document.querySelector('header');
const mainContent = document.querySelector('main.flex-1');
const sidebarInset = document.querySelector('[data-sidebar-inset]');

console.log('Header:', header);
console.log('Header height:', header ? header.offsetHeight : 'not found');
console.log('Header bottom margin:', header ? window.getComputedStyle(header).marginBottom : 'not found');

console.log('\nMain content:', mainContent);
console.log('Main content top margin:', mainContent ? window.getComputedStyle(mainContent).marginTop : 'not found');
console.log('Main content top padding:', mainContent ? window.getComputedStyle(mainContent).paddingTop : 'not found');

console.log('\nSidebarInset:', sidebarInset);
console.log('SidebarInset children:', sidebarInset ? sidebarInset.children.length : 'not found');

if (sidebarInset) {
  console.log('\nAll children of SidebarInset:');
  Array.from(sidebarInset.children).forEach((child, index) => {
    console.log(`Child ${index}:`, child.tagName, child.className);
    console.log(`  Height: ${child.offsetHeight}px`);
    console.log(`  Display: ${window.getComputedStyle(child).display}`);
    if (child.offsetHeight > 100 && child.tagName !== 'MAIN') {
      console.log('  ⚠️ SUSPICIOUS: Large non-main element!');
    }
  });
}

// Check for any elements with large margins or paddings
document.querySelectorAll('*').forEach(el => {
  const styles = window.getComputedStyle(el);
  const marginTop = parseInt(styles.marginTop);
  const paddingTop = parseInt(styles.paddingTop);
  
  if (marginTop > 50 || paddingTop > 50) {
    console.log('\n⚠️ Element with large top spacing:', el);
    console.log('  Margin-top:', marginTop);
    console.log('  Padding-top:', paddingTop);
  }
});

console.log('\n=== End Debug ===');
