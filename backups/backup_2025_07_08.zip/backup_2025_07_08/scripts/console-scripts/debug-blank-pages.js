// Comprehensive Fixlify Page Debug Script
// Run this in the browser console to diagnose blank pages

(function debugFixlifyPages() {
  console.clear();
  console.log("%c🔍 Fixlify Page Debug Tool", "font-size: 20px; color: #3b82f6; font-weight: bold;");
  console.log("="*50);
  
  // 1. Check Authentication
  console.log("\n📌 Authentication Status:");
  const authToken = localStorage.getItem('fixlify-auth-token');
  const hasAuth = !!authToken;
  console.log(`Auth Token Present: ${hasAuth ? '✅ Yes' : '❌ No'}`);
  if (hasAuth) {
    try {
      const tokenData = JSON.parse(authToken);
      console.log(`Token Type: ${tokenData.token_type || 'Unknown'}`);
      console.log(`Has Access Token: ${!!tokenData.access_token}`);
    } catch (e) {
      console.log("Token format: Non-JSON");
    }
  }

  // 2. Check React App State
  console.log("\n⚛️ React App State:");
  const reactRoot = document.getElementById('root');
  const hasReactRoot = !!reactRoot;
  const reactRootEmpty = reactRoot && reactRoot.children.length === 0;
  
  console.log(`React Root Element: ${hasReactRoot ? '✅ Found' : '❌ Missing'}`);
  console.log(`Root Element Empty: ${reactRootEmpty ? '⚠️ Yes (Possible render issue)' : '✅ No'}`);
  console.log(`Root Children Count: ${reactRoot ? reactRoot.children.length : 0}`);

  // 3. Check Page Structure
  console.log("\n📄 Page Structure:");
  const pageElements = {
    'Main Element': document.querySelector('main'),
    'Sidebar': document.querySelector('[class*="sidebar"]'),
    'Header': document.querySelector('header, [class*="header"]'),
    'Page Layout': document.querySelector('[class*="page-layout"], [class*="PageLayout"]'),
    'Error Boundary': document.querySelector('[class*="error"], [role="alert"]'),
    'Loading Spinner': document.querySelector('[class*="spinner"], [class*="loading"]'),
    'Content Cards': document.querySelectorAll('[class*="card"]').length + ' cards',
  };
  
  Object.entries(pageElements).forEach(([name, element]) => {
    console.log(`${name}: ${element ? '✅ Present' : '❌ Missing'}`);
  });

  // 4. Check Console Errors
  console.log("\n⚠️ Recent Console Errors:");
  const originalError = console.error;
  let errorCount = 0;
  console.error = function(...args) {
    errorCount++;
    originalError.apply(console, args);
  };
  console.log(`Error count in current session: ${errorCount}`);
  console.log("Check the Console tab for red error messages");

  // 5. Network Analysis
  console.log("\n🌐 Network Analysis:");
  console.log("Open Network tab and look for:");
  console.log("- Failed requests (red status codes)");
  console.log("- 401/403 Authentication errors");
  console.log("- 500 Server errors");
  console.log("- CORS errors");

  // 6. Supabase Connection
  console.log("\n🗄️ Supabase Connection:");
  const supabaseUrl = import.meta?.env?.VITE_SUPABASE_URL;
  const supabaseKey = import.meta?.env?.VITE_SUPABASE_ANON_KEY;
  console.log(`Supabase URL: ${supabaseUrl ? '✅ Configured' : '❌ Missing'}`);
  console.log(`Supabase Key: ${supabaseKey ? '✅ Configured' : '❌ Missing'}`);

  // 7. Route Information
  console.log("\n🛣️ Current Route:");
  console.log(`Path: ${window.location.pathname}`);
  console.log(`Full URL: ${window.location.href}`);
  
  // 8. DOM Content Analysis
  console.log("\n📊 DOM Content Analysis:");
  const mainElement = document.querySelector('main');
  if (mainElement) {
    const textContent = mainElement.textContent || '';
    console.log(`Main content length: ${textContent.trim().length} characters`);
    console.log(`Has meaningful content: ${textContent.trim().length > 50 ? '✅ Yes' : '❌ No'}`);
    
    // Check for common empty states
    const emptyStates = [
      'loading', 'Loading', 'LOADING',
      'no data', 'No data', 'NO DATA',
      'empty', 'Empty', 'EMPTY',
      'error', 'Error', 'ERROR'
    ];
    
    const hasEmptyState = emptyStates.some(state => textContent.includes(state));
    console.log(`Contains empty state text: ${hasEmptyState ? '⚠️ Yes' : '✅ No'}`);
  }

  // 9. Check for Hidden Elements
  console.log("\n👻 Hidden Elements Check:");
  const hiddenByClass = document.querySelectorAll('[class*="hidden"], .hidden').length;
  const hiddenByStyle = document.querySelectorAll('[style*="display: none"], [style*="display:none"]').length;
  const hiddenByVisibility = document.querySelectorAll('[style*="visibility: hidden"], [style*="visibility:hidden"]').length;
  
  console.log(`Elements with hidden class: ${hiddenByClass}`);
  console.log(`Elements with display:none: ${hiddenByStyle}`);
  console.log(`Elements with visibility:hidden: ${hiddenByVisibility}`);

  // 10. Recommendations
  console.log("\n💡 Troubleshooting Steps:");
  
  const issues = [];
  
  if (!hasAuth) {
    issues.push("1. No authentication token found - Try logging in again");
  }
  
  if (reactRootEmpty) {
    issues.push("2. React root is empty - Check for JavaScript errors preventing render");
  }
  
  if (!pageElements['Main Element']) {
    issues.push("3. No main element found - Page layout might be broken");
  }
  
  if (!pageElements['Sidebar']) {
    issues.push("4. No sidebar found - Layout components might not be loading");
  }
  
  if (issues.length === 0) {
    issues.push("✅ Basic checks passed - Check Network tab for API errors");
    issues.push("✅ Check Console tab for JavaScript errors");
    issues.push("✅ Try hard refresh (Ctrl+Shift+R or Cmd+Shift+R)");
  }
  
  issues.forEach(issue => console.log(issue));

  // Return summary object
  return {
    authentication: hasAuth,
    reactRendered: hasReactRoot && !reactRootEmpty,
    hasContent: mainElement && mainElement.textContent.trim().length > 50,
    currentPath: window.location.pathname,
    recommendations: issues
  };
})();