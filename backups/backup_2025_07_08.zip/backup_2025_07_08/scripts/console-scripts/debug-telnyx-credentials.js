// Quick SMS Debug Script
// This will help identify the exact issue with Telnyx SMS

console.clear();
console.log("🔍 TELNYX SMS DEBUG");
console.log("==================\n");

async function debugTelnyxIssue() {
  try {
    // 1. First, let's check if the API key is configured
    console.log("1️⃣ Checking Telnyx configuration...");
    
    const { data: { session } } = await window.supabase.auth.getSession();
    if (!session) {
      console.error("❌ Not logged in!");
      return;
    }
    
    const configResponse = await fetch('https://mqppvcrlvsgrsqelglod.supabase.co/functions/v1/check-telnyx-key', {
      headers: {
        'Authorization': 'Bearer ' + session.access_token,
        'Content-Type': 'application/json'
      }
    });
    
    const configResult = await configResponse.json();
    console.log("Config check result:", configResult);
    
    // 2. Now let's try a different approach - check if we can access Telnyx directly
    console.log("\n2️⃣ Testing direct Telnyx API access...");
    
    // This will use the edge function to test Telnyx connectivity
    const testResponse = await fetch('https://mqppvcrlvsgrsqelglod.supabase.co/functions/v1/test-telnyx-connection', {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + session.access_token,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({})
    });
    
    if (testResponse.ok) {
      const testResult = await testResponse.json();
      console.log("Telnyx connection test:", testResult);
    } else {
      console.error("Telnyx connection test failed:", await testResponse.text());
    }
    
    // 3. Let's check the actual error from Telnyx
    console.log("\n3️⃣ Attempting to send SMS with detailed logging...");
    
    const smsResponse = await fetch('https://mqppvcrlvsgrsqelglod.supabase.co/functions/v1/telnyx-sms', {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + session.access_token,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        recipientPhone: '+16474242323', // Test number
        message: 'Debug test from Fixlify',
        user_id: session.user.id
      })
    });
    
    const smsResult = await smsResponse.json();
    console.log("SMS Response:", smsResult);
    
    // 4. If it's a credential error, it might be the API key format
    if (smsResult.error && smsResult.error.includes('credentials')) {
      console.log("\n⚠️ CREDENTIAL ERROR DETECTED!");
      console.log("Possible issues:");
      console.log("1. The TELNYX_API_KEY in Supabase secrets might be incorrect");
      console.log("2. The API key might have extra spaces or quotes");
      console.log("3. The API key might be expired or invalid");
      console.log("\n📋 To fix:");
      console.log("1. Go to https://portal.telnyx.com");
      console.log("2. Navigate to API Keys");
      console.log("3. Create a new API key or copy existing one");
      console.log("4. Go to https://supabase.com/dashboard/project/mqppvcrlvsgrsqelglod/functions/secrets");
      console.log("5. Update TELNYX_API_KEY with the exact key (no quotes, no spaces)");
      console.log("6. Wait 2-3 minutes for changes to propagate");
    }
    
  } catch (error) {
    console.error("Debug failed:", error);
  }
}

// Alternative: Test with a mock Telnyx request
async function testTelnyxFormat() {
  console.log("\n📝 Testing Telnyx API format...");
  
  // This shows what the request should look like
  const mockRequest = {
    from: '+12898192158',
    to: '+16474242323',
    text: 'Test message',
    messaging_profile_id: '5ddd8f6113a7fa8ce2d5a22f21d5b245b8a03f04b1dc4231af30a68e9ea60dc2'
  };
  
  console.log("Expected request format:", JSON.stringify(mockRequest, null, 2));
  console.log("\nMake sure your Telnyx API key:");
  console.log("- Starts with 'KEY' (not 'Bearer KEY')");
  console.log("- Has no extra spaces or quotes");
  console.log("- Is the V2 API key (not V1)");
}

// Run the debug
debugTelnyxIssue();
testTelnyxFormat();

console.log("\n💡 If you see 'Could not find any usable credentials', the issue is 100% with the API key in Supabase secrets.");
