// Debug Edge Function Issues
// Run this to check what's happening with SMS

async function debugSMSIssue() {
  const { supabase } = window;
  
  console.log('🔍 Debugging SMS Edge Functions...\n');
  
  // First, let's test the telnyx-sms function directly
  console.log('1️⃣ Testing telnyx-sms directly...');
  
  try {
    const { data, error } = await supabase.functions.invoke('telnyx-sms', {
      body: {
        recipientPhone: '+1234567890',
        message: 'Direct test from debug script',
        user_id: (await supabase.auth.getUser()).data.user?.id
      }
    });
    
    console.log('Direct telnyx-sms response:', { data, error });
  } catch (err) {
    console.error('Direct test error:', err);
  }
  
  // Now test send-estimate-sms
  console.log('\n2️⃣ Testing send-estimate-sms...');
  
  // First, get an estimate to test with
  const { data: estimates } = await supabase
    .from('estimates')
    .select('id, estimate_number')
    .limit(1);
    
  if (estimates && estimates.length > 0) {
    const estimateId = estimates[0].id;
    console.log('Using estimate:', estimates[0].estimate_number);
    
    try {
      const { data, error } = await supabase.functions.invoke('send-estimate-sms', {
        body: {
          estimateId: estimateId,
          recipientPhone: '+1234567890'
        }
      });
      
      console.log('send-estimate-sms response:', { data, error });
    } catch (err) {
      console.error('Estimate SMS error:', err);
    }
  } else {
    console.log('No estimates found to test with');
  }
  
  // Check API key status
  console.log('\n3️⃣ Checking edge function environment...');
  console.log('Dashboard URL: https://supabase.com/dashboard/project/mqppvcrlvsgrsqelglod/functions/secrets');
  console.log('Make sure TELNYX_API_KEY is set to: KEY0197DAA8BF3E951E5527CAA98E7770FC');
  console.log('(No quotes, no spaces)');
  
  // Check phone number status
  console.log('\n4️⃣ Checking phone numbers...');
  const { data: phones } = await supabase
    .from('telnyx_phone_numbers')
    .select('*')
    .eq('status', 'active');
    
  if (phones && phones.length > 0) {
    console.log('Active phone numbers:');
    phones.forEach(p => {
      console.log(`  📱 ${p.phone_number} - User: ${p.user_id || 'unassigned'}`);
    });
  }
  
  console.log('\n📋 Check the edge function logs at:');
  console.log('https://supabase.com/dashboard/project/mqppvcrlvsgrsqelglod/functions/telnyx-sms/logs');
}

// Run it
debugSMSIssue();