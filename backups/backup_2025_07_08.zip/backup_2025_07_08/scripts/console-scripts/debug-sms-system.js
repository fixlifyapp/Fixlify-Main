// Comprehensive SMS System Debug Script
// Run this in the browser console while logged into Fixlify

async function debugSMSSystem() {
    console.log('🔍 Starting SMS System Debug...');
    console.log('================================');
    
    // 1. Check authentication
    console.log('\n1️⃣ Checking Authentication...');
    const session = JSON.parse(localStorage.getItem('fixlify-auth-token'));
    if (!session || !session.access_token) {
        console.error('❌ Not logged in! Please log in to Fixlify first.');
        return;
    }
    console.log('✅ Authenticated as:', session.user.email);
    console.log('   User ID:', session.user.id);
    
    // 2. Initialize Supabase client
    const { createClient } = window.supabase;
    const supabase = createClient(
        'https://mqppvcrlvsgrsqelglod.supabase.co',
        'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1xcHB2Y3JsdnNncnNxZWxnbG9kIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDc1OTE3MDUsImV4cCI6MjA2MzE2NzcwNX0.My-KiqG1bCMqzUru4m59d4v18N3WGxNoNtFPOFAmhzg',
        {
            auth: {
                persistSession: true,
                storage: window.localStorage,
                storageKey: 'fixlify-auth-token'
            }
        }
    );
    
    // 3. Check phone numbers
    console.log('\n2️⃣ Checking Phone Numbers...');
    const { data: phones, error: phoneError } = await supabase
        .from('telnyx_phone_numbers')
        .select('*')
        .eq('status', 'active');
    
    if (phoneError) {
        console.error('❌ Error fetching phone numbers:', phoneError);
    } else if (!phones || phones.length === 0) {
        console.error('❌ No active phone numbers found!');
    } else {
        console.log('✅ Found', phones.length, 'active phone number(s):');
        phones.forEach(phone => {
            console.log('   📱', phone.phone_number);
            console.log('      User ID:', phone.user_id || 'Not assigned');
            console.log('      Your User ID:', session.user.id);
            console.log('      Match:', phone.user_id === session.user.id ? '✅ Yes' : '❌ No');
        });
    }
    
    // 4. Test Edge Function directly
    console.log('\n3️⃣ Testing Edge Function...');
    const testPhone = prompt('Enter test phone number (with country code, e.g., +1234567890):');
    if (!testPhone) {
        console.log('⚠️  Test cancelled - no phone number provided');
        return;
    }
    
    const testMessage = 'Test SMS from Fixlify - ' + new Date().toLocaleString();
    
    console.log('📤 Sending test SMS...');
    console.log('   To:', testPhone);
    console.log('   Message:', testMessage);
    
    try {
        const response = await fetch('https://mqppvcrlvsgrsqelglod.supabase.co/functions/v1/telnyx-sms', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${session.access_token}`,
                'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1xcHB2Y3JsdnNncnNxZWxnbG9kIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDc1OTE3MDUsImV4cCI6MjA2MzE2NzcwNX0.My-KiqG1bCMqzUru4m59d4v18N3WGxNoNtFPOFAmhzg'
            },
            body: JSON.stringify({
                recipientPhone: testPhone,
                message: testMessage
            })
        });
        
        console.log('   Response Status:', response.status);
        console.log('   Response Headers:', Object.fromEntries(response.headers.entries()));
        
        const result = await response.json();
        console.log('   Response Body:', result);
        
        if (response.ok && result.success) {
            console.log('\n✅ SMS SENT SUCCESSFULLY!');
            console.log('   From:', result.from);
            console.log('   To:', result.to);
            console.log('   Message ID:', result.messageId);
            
            // Check if message was logged
            console.log('\n4️⃣ Checking Message Log...');
            const { data: messages, error: msgError } = await supabase
                .from('messages')
                .select('*')
                .eq('message_sid', result.messageId)
                .single();
            
            if (messages) {
                console.log('✅ Message logged in database');
            } else {
                console.log('⚠️  Message not found in database logs');
            }
            
        } else {
            console.error('\n❌ SMS FAILED!');
            console.error('   Error:', result.error);
            
            // Provide specific troubleshooting based on error
            if (result.error === 'SMS service not configured. Please contact support.') {
                console.log('\n🔧 TROUBLESHOOTING:');
                console.log('   The TELNYX_API_KEY might not be properly set or recognized.');
                console.log('   Since you already added it to Supabase, try:');
                console.log('   1. Wait a few minutes for the secret to propagate');
                console.log('   2. Check if the key format is correct (no extra spaces)');
                console.log('   3. Verify the key is active in your Telnyx account');
            } else if (result.error.includes('phone number')) {
                console.log('\n🔧 TROUBLESHOOTING:');
                console.log('   Phone number issue detected. Check:');
                console.log('   1. Phone number format (must include country code)');
                console.log('   2. Phone number is valid for SMS');
                console.log('   3. No spaces or special characters except +');
            }
        }
        
    } catch (error) {
        console.error('❌ Network error:', error);
        console.log('\n🔧 TROUBLESHOOTING:');
        console.log('   1. Check your internet connection');
        console.log('   2. Verify Supabase Edge Functions are running');
        console.log('   3. Check browser console for CORS errors');
    }
    
    console.log('\n5️⃣ Debug Summary:');
    console.log('================================');
    console.log('User:', session.user.email);
    console.log('User ID:', session.user.id);
    console.log('Active Phone Numbers:', phones?.length || 0);
    console.log('Edge Function URL:', 'https://mqppvcrlvsgrsqelglod.supabase.co/functions/v1/telnyx-sms');
    console.log('\nIf SMS is still not working after adding TELNYX_API_KEY:');
    console.log('1. The secret might need a few minutes to propagate');
    console.log('2. Try checking Edge Function logs in Supabase dashboard');
    console.log('3. Verify your Telnyx account has SMS enabled and credits');
}

// Run the debug automatically
console.log('SMS Debug Script Loaded!');
console.log('Running debug automatically...');
debugSMSSystem();
