// Test script to debug messaging system
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://mqppvcrlvsgrsqelglod.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1xcHB2Y3JsdnNncnNxZWxnbG9kIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDc1OTE3MDUsImV4cCI6MjA2MzE2NzcwNX0.My-KiqG1bCMqzUru4m59d4v18N3WGxNoNtFPOFAmhzg';

const supabase = createClient(supabaseUrl, supabaseAnonKey);

async function testMessagingSystem() {
  console.log('🔍 Testing Messaging System...\n');

  // 1. Check authentication
  console.log('1️⃣ Checking authentication...');
  const { data: { user }, error: authError } = await supabase.auth.getUser();
  
  if (authError || !user) {
    console.error('❌ Not authenticated. Please log in first.');
    console.log('Run this in the browser console while logged in to the app.');
    return;
  }
  
  console.log('✅ Authenticated as:', user.email);
  console.log('User ID:', user.id);
  
  // 2. Get auth token
  const { data: { session } } = await supabase.auth.getSession();
  if (!session) {
    console.error('❌ No session found');
    return;
  }
  
  console.log('✅ Session token available');
  
  // 3. Check Telnyx phone numbers
  console.log('\n2️⃣ Checking Telnyx phone numbers...');
  const { data: phoneNumbers, error: phoneError } = await supabase
    .from('telnyx_phone_numbers')
    .select('*');
    
  if (phoneError) {
    console.error('❌ Error fetching phone numbers:', phoneError);
  } else {
    console.log('📱 Phone numbers found:', phoneNumbers?.length || 0);
    phoneNumbers?.forEach(phone => {
      console.log(`  - ${phone.phone_number} (${phone.status})`);
    });
  }
  
  // 4. Test sending SMS via edge function
  console.log('\n3️⃣ Testing SMS edge function...');
  try {
    const testPhone = '+15551234567'; // Test US number
    const { data, error } = await supabase.functions.invoke('telnyx-sms', {
      body: {
        recipientPhone: testPhone,
        message: 'Test message from debug script',
        client_id: null,
        job_id: null
      }
    });
    
    if (error) {
      console.error('❌ SMS edge function error:', error);
    } else {
      console.log('✅ SMS edge function response:', data);
    }
  } catch (e) {
    console.error('❌ Failed to invoke SMS function:', e);
  }
  
  // 5. Test estimate sending
  console.log('\n4️⃣ Checking estimates...');
  const { data: estimates, error: estimateError } = await supabase
    .from('estimates')
    .select('id, estimate_number, total')
    .limit(1);
    
  if (estimateError) {
    console.error('❌ Error fetching estimates:', estimateError);
  } else if (estimates && estimates.length > 0) {
    console.log('📄 Found estimate:', estimates[0]);
    
    // Try to send it
    console.log('\n5️⃣ Testing estimate email sending...');
    const { data: sendData, error: sendError } = await supabase.functions.invoke('send-estimate', {
      body: {
        estimateId: estimates[0].id,
        recipientEmail: 'test@example.com',
        customMessage: 'Test from debug script'
      }
    });
    
    if (sendError) {
      console.error('❌ Send estimate error:', sendError);
    } else {
      console.log('✅ Send estimate response:', sendData);
    }
  }
  
  // 6. Check communication logs
  console.log('\n6️⃣ Checking recent communication logs...');
  const { data: logs, error: logError } = await supabase
    .from('estimate_communications')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(5);
    
  if (logError) {
    console.error('❌ Error fetching logs:', logError);
  } else {
    console.log('📝 Recent communications:', logs?.length || 0);
    logs?.forEach(log => {
      console.log(`  - ${log.communication_type} to ${log.recipient} (${log.status})`);
    });
  }
  
  console.log('\n✨ Messaging system test complete!');
}

// Instructions to run
console.log(`
📋 Instructions:
1. Open your Fixlify app in the browser
2. Log in to your account
3. Open the browser console (F12)
4. Copy and paste this entire script
5. Call: testMessagingSystem()
`);

// Make function available globally
window.testMessagingSystem = testMessagingSystem;
