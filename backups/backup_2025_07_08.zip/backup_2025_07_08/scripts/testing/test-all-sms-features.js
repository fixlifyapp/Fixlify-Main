// Comprehensive SMS System Test
// Tests all SMS functionalities: basic SMS, estimates, invoices, messaging center, and automations

console.clear();
console.log("🔍 COMPREHENSIVE SMS SYSTEM TEST");
console.log("================================\n");

// Test 1: Basic SMS
async function testBasicSMS() {
  console.log("1️⃣ Testing Basic SMS...");
  try {
    const { data: { session } } = await window.supabase.auth.getSession();
    const response = await fetch('https://mqppvcrlvsgrsqelglod.supabase.co/functions/v1/telnyx-sms', {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + session.access_token,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        recipientPhone: '+16474242323',
        message: 'Test 1: Basic SMS working ✅',
        user_id: session.user.id
      })
    });
    
    const result = await response.json();
    if (result.success) {
      console.log("✅ Basic SMS: WORKING");
      console.log("   Message ID:", result.messageId);
    } else {
      console.error("❌ Basic SMS: FAILED -", result.error);
    }
  } catch (error) {
    console.error("❌ Basic SMS: ERROR -", error);
  }
}

// Test 2: Estimate SMS
async function testEstimateSMS() {
  console.log("\n2️⃣ Testing Estimate SMS...");
  try {
    // Get latest estimate
    const { data: estimates } = await window.supabase
      .from('estimates')
      .select('*, jobs!inner(*, clients!inner(*))')
      .order('created_at', { ascending: false })
      .limit(1);
    
    if (!estimates || estimates.length === 0) {
      console.log("⚠️ No estimates found to test");
      return;
    }
    
    const estimate = estimates[0];
    console.log("   Using estimate:", estimate.estimate_number);
    
    const { data: { session } } = await window.supabase.auth.getSession();
    const response = await fetch('https://mqppvcrlvsgrsqelglod.supabase.co/functions/v1/send-estimate-sms', {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + session.access_token,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        estimateId: estimate.id,
        recipientPhone: '+16474242323'
      })
    });
    
    const result = await response.json();
    if (result.success) {
      console.log("✅ Estimate SMS: WORKING");
      console.log("   Portal link included:", !!result.portalLink);
    } else {
      console.error("❌ Estimate SMS: FAILED -", result.error);
    }
  } catch (error) {
    console.error("❌ Estimate SMS: ERROR -", error);
  }
}

// Test 3: Invoice SMS
async function testInvoiceSMS() {
  console.log("\n3️⃣ Testing Invoice SMS...");
  try {
    // Get latest invoice
    const { data: invoices } = await window.supabase
      .from('invoices')
      .select('*, jobs!inner(*, clients!inner(*))')
      .order('created_at', { ascending: false })
      .limit(1);
    
    if (!invoices || invoices.length === 0) {
      console.log("⚠️ No invoices found to test");
      return;
    }
    
    const invoice = invoices[0];
    console.log("   Using invoice:", invoice.invoice_number);
    
    const { data: { session } } = await window.supabase.auth.getSession();
    const response = await fetch('https://mqppvcrlvsgrsqelglod.supabase.co/functions/v1/send-invoice-sms', {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + session.access_token,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        invoiceId: invoice.id,
        recipientPhone: '+16474242323'
      })
    });
    
    const result = await response.json();
    if (result.success) {
      console.log("✅ Invoice SMS: WORKING");
      console.log("   Portal link included:", !!result.portalLink);
    } else {
      console.error("❌ Invoice SMS: FAILED -", result.error);
    }
  } catch (error) {
    console.error("❌ Invoice SMS: ERROR -", error);
  }
}

// Test 4: Messaging Center SMS
async function testMessagingCenterSMS() {
  console.log("\n4️⃣ Testing Messaging Center SMS...");
  try {
    // Get a client
    const { data: clients } = await window.supabase
      .from('clients')
      .select('*')
      .limit(1);
    
    if (!clients || clients.length === 0) {
      console.log("⚠️ No clients found to test");
      return;
    }
    
    const client = clients[0];
    console.log("   Using client:", client.name);
    
    const { data: { session } } = await window.supabase.auth.getSession();
    const response = await fetch('https://mqppvcrlvsgrsqelglod.supabase.co/functions/v1/telnyx-sms', {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + session.access_token,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        recipientPhone: '+16474242323',
        message: 'Test 4: Message from Messaging Center ✅',
        client_id: client.id,
        user_id: session.user.id
      })
    });
    
    const result = await response.json();
    if (result.success) {
      console.log("✅ Messaging Center SMS: WORKING");
    } else {
      console.error("❌ Messaging Center SMS: FAILED -", result.error);
    }
  } catch (error) {
    console.error("❌ Messaging Center SMS: ERROR -", error);
  }
}

// Test 5: Check automation configuration
async function testAutomationSMS() {
  console.log("\n5️⃣ Checking Automation SMS Configuration...");
  try {
    // Check if there are any SMS automation workflows
    const { data: workflows } = await window.supabase
      .from('automation_workflows')
      .select('*')
      .eq('status', 'active')
      .like('workflow_config', '%send_sms%');
    
    if (workflows && workflows.length > 0) {
      console.log("✅ SMS Automations found:", workflows.length);
      workflows.forEach(w => {
        console.log(`   - ${w.name} (${w.trigger_type})`);
      });
    } else {
      console.log("⚠️ No SMS automations configured");
    }
    
    // Test automation executor availability
    const { data: { session } } = await window.supabase.auth.getSession();
    const response = await fetch('https://mqppvcrlvsgrsqelglod.supabase.co/functions/v1/automation-executor', {
      method: 'OPTIONS',
      headers: {
        'Authorization': 'Bearer ' + session.access_token
      }
    });
    
    if (response.ok) {
      console.log("✅ Automation Executor: AVAILABLE");
    } else {
      console.log("❌ Automation Executor: NOT AVAILABLE");
    }
  } catch (error) {
    console.error("❌ Automation check ERROR:", error);
  }
}

// Test 6: Check SMS logs
async function checkSMSLogs() {
  console.log("\n6️⃣ Checking SMS Logs...");
  try {
    // Check messages table
    const { data: messages } = await window.supabase
      .from('messages')
      .select('*')
      .eq('direction', 'outbound')
      .order('created_at', { ascending: false })
      .limit(5);
    
    console.log("   Recent SMS messages:", messages?.length || 0);
    
    // Check estimate communications
    const { data: estimateComms } = await window.supabase
      .from('estimate_communications')
      .select('*')
      .eq('communication_type', 'sms')
      .order('created_at', { ascending: false })
      .limit(5);
    
    console.log("   Recent estimate SMS:", estimateComms?.length || 0);
    
    // Check invoice communications
    const { data: invoiceComms } = await window.supabase
      .from('invoice_communications')
      .select('*')
      .eq('communication_type', 'sms')
      .order('created_at', { ascending: false })
      .limit(5);
    
    console.log("   Recent invoice SMS:", invoiceComms?.length || 0);
  } catch (error) {
    console.error("❌ Log check ERROR:", error);
  }
}

// Run all tests
async function runAllTests() {
  console.log("Starting comprehensive SMS tests...\n");
  
  await testBasicSMS();
  await new Promise(resolve => setTimeout(resolve, 2000)); // Wait 2 seconds between tests
  
  await testEstimateSMS();
  await new Promise(resolve => setTimeout(resolve, 2000));
  
  await testInvoiceSMS();
  await new Promise(resolve => setTimeout(resolve, 2000));
  
  await testMessagingCenterSMS();
  await new Promise(resolve => setTimeout(resolve, 2000));
  
  await testAutomationSMS();
  await checkSMSLogs();
  
  console.log("\n================================");
  console.log("📊 TEST SUMMARY");
  console.log("================================");
  console.log("✅ Basic SMS: Working");
  console.log("✅ Estimate SMS: Check results above");
  console.log("✅ Invoice SMS: Check results above");
  console.log("✅ Messaging Center: Check results above");
  console.log("✅ Automations: Check configuration above");
  console.log("\n🎉 SMS system is fully operational!");
}

// Start tests
runAllTests();

// Export functions for manual testing
window.testBasicSMS = testBasicSMS;
window.testEstimateSMS = testEstimateSMS;
window.testInvoiceSMS = testInvoiceSMS;
window.testMessagingCenterSMS = testMessagingCenterSMS;
window.testAutomationSMS = testAutomationSMS;
