// Test Environment Variables
// This will show exactly how the API key is stored

async function testEnvVars() {
  const { supabase } = window;
  
  console.log('🔍 Testing environment variables...\n');
  
  try {
    const { data, error } = await supabase.functions.invoke('test-env');
    
    if (error) {
      console.error('❌ Error:', error);
      return;
    }
    
    if (data?.keyInfo) {
      const info = data.keyInfo;
      console.log('📋 TELNYX_API_KEY Information:');
      console.log('  Exists:', info.exists ? '✅ Yes' : '❌ No');
      console.log('  Length:', info.length, 'characters');
      console.log('  Starts with KEY:', info.startsWithKEY ? '✅ Yes' : '❌ No');
      console.log('  First 8 chars:', info.firstChars);
      console.log('  Last 4 chars:', info.lastChars);
      console.log('  Has spaces:', info.hasSpaces ? '❌ Yes (BAD!)' : '✅ No');
      console.log('  Has quotes:', info.hasQuotes ? '❌ Yes (BAD!)' : '✅ No');
      console.log('  Trimmed length:', info.trimmedLength);
      
      if (info.hasSpaces || info.hasQuotes) {
        console.log('\n⚠️ PROBLEM FOUND!');
        console.log('The API key has extra characters (spaces or quotes).');
        console.log('Please update it in Supabase Edge Functions > Secrets');
        console.log('Remove any quotes or spaces around the key.');
      }
      
      if (!info.startsWithKEY) {
        console.log('\n⚠️ API key should start with "KEY"');
        console.log('Make sure you\'re using a Telnyx API v2 key');
      }
    }
    
  } catch (err) {
    console.error('❌ Unexpected error:', err);
  }
}

// Run the test
testEnvVars();