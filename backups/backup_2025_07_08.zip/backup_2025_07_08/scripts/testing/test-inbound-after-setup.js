// Quick test to check inbound SMS after adding public key
console.clear();
console.log("🔍 Testing Inbound SMS Reception");
console.log("=================================\n");

// Function to check for recent inbound messages
async function checkInboundSMS() {
  console.log("📱 Checking for inbound messages...");
  
  const { data: messages, error } = await window.supabase
    .from('messages')
    .select('*')
    .eq('direction', 'inbound')
    .order('created_at', { ascending: false })
    .limit(10);
  
  if (error) {
    console.error("❌ Error:", error);
    return;
  }
  
  if (messages && messages.length > 0) {
    console.log(`✅ Found ${messages.length} inbound messages:\n`);
    messages.forEach((msg, index) => {
      console.log(`Message ${index + 1}:`);
      console.log(`  From: ${msg.sender}`);
      console.log(`  To: ${msg.recipient}`);
      console.log(`  Text: "${msg.body}"`);
      console.log(`  Time: ${new Date(msg.created_at).toLocaleString()}`);
      console.log(`  Message ID: ${msg.message_sid}`);
      console.log("  ---");
    });
  } else {
    console.log("⚠️ No inbound messages found yet.");
    console.log("\n📱 To test:");
    console.log("1. Make sure you added TELNYX_PUBLIC_KEY to Supabase secrets");
    console.log("2. Wait 2-3 minutes for it to propagate");
    console.log("3. Send an SMS to: +12898192158");
    console.log("4. Run checkInboundSMS() again");
  }
}

// Function to check webhook logs
async function checkWebhookLogs() {
  console.log("\n📊 Checking Edge Function logs...");
  console.log("Go to: https://supabase.com/dashboard/project/mqppvcrlvsgrsqelglod/functions");
  console.log("Click on 'telnyx-webhook-router' to see if webhooks are arriving");
}

// Function to verify phone configuration
async function verifyPhoneSetup() {
  console.log("\n🔧 Verifying phone number setup...");
  
  const { data: phone } = await window.supabase
    .from('telnyx_phone_numbers')
    .select('*')
    .eq('phone_number', '+12898192158')
    .single();
  
  if (phone) {
    console.log("✅ Phone number configured:");
    console.log(`  Number: ${phone.phone_number}`);
    console.log(`  Status: ${phone.status}`);
    console.log(`  User ID: ${phone.user_id}`);
    console.log(`  Messaging Profile: ${phone.messaging_profile_id ? '✅' : '❌'}`);
  }
}

// Test webhook manually (simulates inbound SMS)
async function testWebhookManually() {
  console.log("\n🧪 Testing webhook manually...");
  
  const testMessage = prompt("Enter test message:", "Test inbound SMS " + new Date().toLocaleTimeString());
  if (!testMessage) return;
  
  try {
    const response = await fetch('https://mqppvcrlvsgrsqelglod.supabase.co/functions/v1/sms-receiver', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        data: {
          event_type: 'message.received',
          id: 'test-' + Date.now(),
          occurred_at: new Date().toISOString(),
          payload: {
            id: 'msg-' + Date.now(),
            direction: 'inbound',
            from: {
              phone_number: '+15551234567'  // Test sender
            },
            to: [{
              phone_number: '+12898192158'  // Your Telnyx number
            }],
            text: testMessage,
            received_at: new Date().toISOString()
          }
        }
      })
    });
    
    const result = await response.json();
    console.log("Webhook test result:", result);
    
    if (result.success) {
      console.log("✅ Webhook processed successfully!");
      console.log("Check your Messaging Center - the test message should appear there!");
    } else {
      console.error("❌ Webhook failed:", result.error);
    }
  } catch (error) {
    console.error("❌ Error:", error);
  }
}

// Run initial checks
console.log("Starting checks...\n");
checkInboundSMS();
verifyPhoneSetup();

// Export functions
window.checkInboundSMS = checkInboundSMS;
window.testWebhookManually = testWebhookManually;

console.log("\n💡 Available commands:");
console.log("  checkInboundSMS() - Check for new inbound messages");
console.log("  testWebhookManually() - Test webhook without real SMS");
console.log("\n📱 Your Telnyx number: +12898192158");
console.log("🔗 Webhook is configured: ✅");
console.log("🔑 Public key needs to be added to Supabase: ⏳");
