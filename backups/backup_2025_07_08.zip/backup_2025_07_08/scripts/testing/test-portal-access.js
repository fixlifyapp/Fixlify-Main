// Test Portal Access Script
// Run this in the browser console to test portal access

async function testPortalAccess(token) {
  console.log("🔍 Testing portal access with token:", token);
  
  try {
    // Get Supabase URL and anon key from the app
    const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
    const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
    
    if (!supabaseUrl || !supabaseAnonKey) {
      console.error("❌ Missing Supabase configuration");
      return;
    }
    
    // Call the portal-data edge function
    const response = await fetch(`${supabaseUrl}/functions/v1/portal-data`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${supabaseAnonKey}`
      },
      body: JSON.stringify({ accessToken: token })
    });
    
    const data = await response.json();
    
    if (!response.ok) {
      console.error("❌ Portal data request failed:", data);
      return;
    }
    
    console.log("✅ Portal data retrieved successfully:");
    console.log("Client:", data.client);
    console.log("Company:", data.company);
    console.log("Jobs:", data.jobs?.length || 0);
    console.log("Estimates:", data.estimates?.length || 0);
    console.log("Invoices:", data.invoices?.length || 0);
    
    return data;
  } catch (error) {
    console.error("❌ Error testing portal access:", error);
  }
}

// Usage: Copy this script to console and run:
// testPortalAccess('your-token-here');

// To generate a new portal link for testing:
console.log(`
📋 To generate a new portal access token:
1. Go to Supabase Dashboard > SQL Editor
2. Run the queries from debug-portal-access.sql
3. Use the generate_portal_access function with a valid client ID
4. The function will return a token you can use to access the portal
5. Access the portal at: ${window.location.origin}/portal/[YOUR_TOKEN]
`);