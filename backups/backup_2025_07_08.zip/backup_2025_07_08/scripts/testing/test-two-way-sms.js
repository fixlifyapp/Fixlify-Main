// Two-Way SMS Testing Script
// Tests both outbound and inbound SMS functionality

console.clear();
console.log("📱 TWO-WAY SMS SYSTEM TEST");
console.log("==========================\n");

// Test 1: Check Phone Number Configuration
async function checkPhoneConfig() {
  console.log("1️⃣ Checking phone number configuration...");
  
  const { data: phoneNumbers, error } = await window.supabase
    .from('telnyx_phone_numbers')
    .select('*')
    .eq('status', 'active');
  
  if (error) {
    console.error("❌ Error fetching phone numbers:", error);
    return;
  }
  
  console.log("📱 Active phone numbers:");
  phoneNumbers.forEach(phone => {
    console.log(`   - ${phone.phone_number} (User: ${phone.user_id || 'Not assigned'})`);
    console.log(`     Features: ${phone.features?.join(', ')}`);
    console.log(`     Messaging Profile: ${phone.messaging_profile_id ? '✅' : '❌'}`);
  });
}

// Test 2: Test Outbound SMS
async function testOutboundSMS() {
  console.log("\n2️⃣ Testing outbound SMS...");
  
  const testPhone = prompt("Enter phone number to test outbound SMS:", "+1");
  if (!testPhone || testPhone === "+1") {
    console.log("⚠️ Test cancelled");
    return;
  }
  
  const { data: { session } } = await window.supabase.auth.getSession();
  
  const response = await fetch('https://mqppvcrlvsgrsqelglod.supabase.co/functions/v1/telnyx-sms', {
    method: 'POST',
    headers: {
      'Authorization': 'Bearer ' + session.access_token,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      recipientPhone: testPhone,
      message: 'Test two-way SMS. Reply to this message to test inbound!',
      user_id: session.user.id
    })
  });
  
  const result = await response.json();
  
  if (result.success) {
    console.log("✅ Outbound SMS sent successfully!");
    console.log("   From:", result.from);
    console.log("   To:", result.to);
    console.log("   Message ID:", result.messageId);
    console.log("\n📱 Now reply to this SMS to test inbound messaging!");
  } else {
    console.error("❌ Outbound SMS failed:", result.error);
  }
}

// Test 3: Check Recent Inbound Messages
async function checkInboundMessages() {
  console.log("\n3️⃣ Checking recent inbound messages...");
  
  const { data: messages, error } = await window.supabase
    .from('messages')
    .select('*')
    .eq('direction', 'inbound')
    .order('created_at', { ascending: false })
    .limit(5);
  
  if (error) {
    console.error("❌ Error fetching messages:", error);
    return;
  }
  
  if (messages && messages.length > 0) {
    console.log("📨 Recent inbound messages:");
    messages.forEach(msg => {
      console.log(`   From: ${msg.sender}`);
      console.log(`   To: ${msg.recipient}`);
      console.log(`   Message: ${msg.body}`);
      console.log(`   Time: ${new Date(msg.created_at).toLocaleString()}`);
      console.log(`   ---`);
    });
  } else {
    console.log("⚠️ No inbound messages found yet");
    console.log("   Send an SMS to +12898192158 to test inbound messaging");
  }
}

// Test 4: Check Conversations
async function checkConversations() {
  console.log("\n4️⃣ Checking recent conversations...");
  
  const { data: conversations, error } = await window.supabase
    .from('conversations')
    .select(`
      *,
      clients(name, phone),
      messages(
        body,
        direction,
        created_at
      )
    `)
    .order('last_message_at', { ascending: false })
    .limit(3);
  
  if (error) {
    console.error("❌ Error fetching conversations:", error);
    return;
  }
  
  if (conversations && conversations.length > 0) {
    console.log("💬 Recent conversations:");
    conversations.forEach(conv => {
      console.log(`   Client: ${conv.clients?.name || 'Unknown'} (${conv.clients?.phone})`);
      console.log(`   Messages: ${conv.messages?.length || 0}`);
      console.log(`   Last activity: ${new Date(conv.last_message_at).toLocaleString()}`);
      
      if (conv.messages && conv.messages.length > 0) {
        const lastMsg = conv.messages[0];
        console.log(`   Last message: ${lastMsg.direction} - "${lastMsg.body.substring(0, 50)}..."`);
      }
      console.log(`   ---`);
    });
  } else {
    console.log("⚠️ No conversations found");
  }
}

// Test 5: Simulate Inbound Webhook
async function simulateInboundWebhook() {
  console.log("\n5️⃣ Simulating inbound SMS webhook...");
  
  const fromPhone = prompt("Enter sender phone number:", "+1234567890");
  const message = prompt("Enter test message:", "Test inbound SMS via webhook");
  
  if (!fromPhone || !message) {
    console.log("⚠️ Test cancelled");
    return;
  }
  
  console.log("📤 Sending webhook to sms-receiver...");
  
  try {
    const response = await fetch('https://mqppvcrlvsgrsqelglod.supabase.co/functions/v1/sms-receiver', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        data: {
          event_type: 'message.received',
          id: `test-${Date.now()}`,
          occurred_at: new Date().toISOString(),
          payload: {
            id: `msg-test-${Date.now()}`,
            direction: 'inbound',
            from: {
              phone_number: fromPhone
            },
            to: [{
              phone_number: '+12898192158'
            }],
            text: message,
            received_at: new Date().toISOString()
          }
        }
      })
    });
    
    const result = await response.json();
    
    if (result.success) {
      console.log("✅ Webhook processed successfully!");
      console.log("   Details:", result.details);
      console.log("\n💡 Check Messaging Center - the message should appear there!");
    } else {
      console.error("❌ Webhook processing failed:", result.error);
    }
  } catch (error) {
    console.error("❌ Error sending webhook:", error);
  }
}

// Test 6: Check Webhook Configuration
async function checkWebhookConfig() {
  console.log("\n6️⃣ Webhook Configuration Info...");
  
  console.log("📋 Your webhook URL for Telnyx:");
  console.log("   https://mqppvcrlvsgrsqelglod.supabase.co/functions/v1/telnyx-webhook-router");
  console.log("\n⚙️ Configure this in Telnyx Portal:");
  console.log("   1. Go to portal.telnyx.com");
  console.log("   2. Navigate to Messaging → Messaging Profiles");
  console.log("   3. Click on your profile");
  console.log("   4. Set the webhook URL above");
  console.log("   5. Enable: Message Received, Sent, Delivered, Failed");
  
  console.log("\n🔐 Webhook Security:");
  console.log("   - Signature verification: Enabled");
  console.log("   - Public key stored in edge function");
  console.log("   - Timestamp validation: ±30 seconds");
}

// Run all tests
async function runAllTests() {
  console.log("Running comprehensive two-way SMS tests...\n");
  
  await checkPhoneConfig();
  await checkInboundMessages();
  await checkConversations();
  checkWebhookConfig();
  
  console.log("\n================================");
  console.log("📊 TWO-WAY SMS TEST SUMMARY");
  console.log("================================");
  console.log("✅ Outbound SMS: Working (previously tested)");
  console.log("✅ Phone Configuration: Check results above");
  console.log("✅ Webhook Endpoint: Deployed and ready");
  console.log("✅ SMS Receiver: Handling v2 webhooks");
  console.log("\n🎯 Next Steps:");
  console.log("1. Run testOutboundSMS() to send a test SMS");
  console.log("2. Reply to that SMS from your phone");
  console.log("3. Run checkInboundMessages() to see if it arrived");
  console.log("4. Or use simulateInboundWebhook() to test without real SMS");
}

// Start tests
runAllTests();

// Export functions for manual testing
window.testOutboundSMS = testOutboundSMS;
window.checkInboundMessages = checkInboundMessages;
window.checkConversations = checkConversations;
window.simulateInboundWebhook = simulateInboundWebhook;
window.checkWebhookConfig = checkWebhookConfig;

console.log("\n💡 Available test functions:");
console.log("   testOutboundSMS() - Send a test SMS");
console.log("   checkInboundMessages() - Check for received SMS");
console.log("   checkConversations() - View recent conversations");
console.log("   simulateInboundWebhook() - Test webhook without real SMS");
