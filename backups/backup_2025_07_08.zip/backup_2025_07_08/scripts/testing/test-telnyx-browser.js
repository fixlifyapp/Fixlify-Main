// Test if the API key actually works with Telnyx
async function testTelnyxAPIKey() {
  const apiKey = 'KEY0197DAA8BF3E951E5527CAA98E7770FC';
  const fromPhone = '+12898192158';
  const toPhone = '+14377476737';
  
  console.log('Testing Telnyx API directly from browser...');
  
  try {
    const response = await fetch('https://api.telnyx.com/v2/messages', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        from: fromPhone,
        to: toPhone,
        text: 'Test message from browser console'
      })
    });
    
    const result = await response.text();
    console.log('Response status:', response.status);
    console.log('Response:', result);
    
    if (!response.ok) {
      console.error('❌ API call failed');
      const errorData = JSON.parse(result);
      if (errorData.errors) {
        errorData.errors.forEach(err => {
          console.error(`Error ${err.code}: ${err.title}`);
          console.error(`Detail: ${err.detail}`);
        });
      }
    } else {
      console.log('✅ SMS sent successfully!');
    }
  } catch (error) {
    console.error('Network error:', error);
  }
}

// Run the test
testTelnyxAPIKey();