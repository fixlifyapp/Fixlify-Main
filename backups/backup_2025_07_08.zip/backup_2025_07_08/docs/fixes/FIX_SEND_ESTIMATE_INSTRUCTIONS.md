ы SMS убедитесь что:
1. В Supabase добавлены ключи для Telnyx:
   - `TELNYX_API_KEY`
   - `TELNYX_PROFILE_ID` (если требуется)
2. Номер телефона правильно настроен в Telnyx

### 7. Альтернативное решение - прямое обновление функций

Если деплой через CLI не работает, можно обновить функции напрямую:

1. Скопируйте содержимое `send-estimate-fixed/index.ts` 
2. Вставьте его в существующую функцию `send-estimate/index.ts`
3. Аналогично для SMS функции

### 8. Тестирование

После деплоя протестируйте отправку:

1. Откройте estimate в интерфейсе
2. Нажмите "Send Estimate"
3. Выберите Email или SMS
4. Проверьте консоль браузера на ошибки

### 9. Временное решение

Если нужно срочно отправить estimate, можно:
1. Скопировать ссылку на estimate
2. Отправить клиенту вручную через email/SMS
3. Формат ссылки: `https://hub.fixlify.app/portal/[TOKEN]`

## Контакты для настройки

- **Mailgun**: https://app.mailgun.com/
- **Telnyx**: https://portal.telnyx.com/
- **Supabase**: https://supabase.com/dashboard/

## Примечания

- Portal функция (`generate_portal_access`) должна существовать в базе данных
- Таблица `client_portal_access` должна быть создана
- Проверьте RLS политики для этих таблиц
