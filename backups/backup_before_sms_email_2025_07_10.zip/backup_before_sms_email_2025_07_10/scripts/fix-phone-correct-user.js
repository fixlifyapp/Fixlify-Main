// Script to properly assign phone to petrusenkocorp@gmail.com
async function fixPhoneForCorrectUser() {
    const session = JSON.parse(localStorage.getItem('fixlify-auth-token'));
    if (!session) {
        console.error('❌ Not logged in!');
        return;
    }
    
    console.log('🔍 Finding the correct user ID for petrusenkocorp@gmail.com...');
    
    // First, let's find ALL users to see which one is petrusenkocorp@gmail.com
    try {
        // Check profiles table for petrusenkocorp@gmail.com
        const profileResponse = await fetch(
            'https://mqppvcrlvsgrsqelglod.supabase.co/rest/v1/profiles?email=eq.petrusenkocorp@gmail.com',
            {
                headers: {
                    'Authorization': `Bearer ${session.access_token}`,
                    'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1xcHB2Y3JsdnNncnNxZWxnbG9kIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDc1OTE3MDUsImV4cCI6MjA2MzE2NzcwNX0.My-KiqG1bCMqzUru4m59d4v18N3WGxNoNtFPOFAmhzg'
                }
            }
        );
        
        const profiles = await profileResponse.json();
        
        if (profiles.length === 0) {
            console.error('❌ No profile found for petrusenkocorp@gmail.com');
            console.log('Let me check all profiles...');
            
            // Get all profiles to see what's there
            const allProfilesResponse = await fetch(
                'https://mqppvcrlvsgrsqelglod.supabase.co/rest/v1/profiles',
                {
                    headers: {
                        'Authorization': `Bearer ${session.access_token}`,
                        'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1xcHB2Y3JsdnNncnNxZWxnbG9kIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDc1OTE3MDUsImV4cCI6MjA2MzE2NzcwNX0.My-KiqG1bCMqzUru4m59d4v18N3WGxNoNtFPOFAmhzg'
                    }
                }
            );
            
            const allProfiles = await allProfilesResponse.json();
            console.log('\n📋 All profiles in the system:');
            allProfiles.forEach(profile => {
                console.log(`   Email: ${profile.email || 'NO EMAIL'}, ID: ${profile.id}`);
                if (profile.email === 'petrusenkocorp@gmail.com') {
                    console.log('   ✅ FOUND IT!');
                }
            });
            
            // Find the correct profile
            const correctProfile = allProfiles.find(p => p.email === 'petrusenkocorp@gmail.com');
            if (correctProfile) {
                await updatePhoneAssignment(correctProfile.id);
            } else {
                console.error('❌ Could not find petrusenkocorp@gmail.com in profiles');
                console.log('\n🔧 The user ID we need is probably: 6dfbdcae-c484-45aa-9327-763500213f24');
                console.log('This was the original assignment. Let me check if that user exists...');
                
                // Check if the original user ID exists
                await checkOriginalUser();
            }
        } else {
            const correctProfile = profiles[0];
            console.log('✅ Found petrusenkocorp@gmail.com profile!');
            console.log('   User ID:', correctProfile.id);
            console.log('   Email:', correctProfile.email);
            
            await updatePhoneAssignment(correctProfile.id);
        }
    } catch (error) {
        console.error('❌ Error:', error);
    }
}

async function checkOriginalUser() {
    const session = JSON.parse(localStorage.getItem('fixlify-auth-token'));
    const originalUserId = '6dfbdcae-c484-45aa-9327-763500213f24';
    
    console.log('\n🔍 Checking original user ID:', originalUserId);
    
    const response = await fetch(
        `https://mqppvcrlvsgrsqelglod.supabase.co/rest/v1/profiles?id=eq.${originalUserId}`,
        {
            headers: {
                'Authorization': `Bearer ${session.access_token}`,
                'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1xcHB2Y3JsdnNncnNxZWxnbG9kIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDc1OTE3MDUsImV4cCI6MjA2MzE2NzcwNX0.My-KiqG1bCMqzUru4m59d4v18N3WGxNoNtFPOFAmhzg'
            }
        }
    );
    
    const profiles = await response.json();
    if (profiles.length > 0) {
        const profile = profiles[0];
        console.log('✅ Found user with ID:', originalUserId);
        console.log('   Email:', profile.email || 'NO EMAIL SET');
        console.log('   Name:', profile.name || 'NO NAME');
        
        if (profile.email === 'petrusenkocorp@gmail.com') {
            console.log('   ✅ This IS the petrusenkocorp@gmail.com account!');
            console.log('   The phone is already assigned correctly.');
            console.log('\n🔑 The issue is that you are logged in with a different account!');
            console.log('   Current session user:', session.user.email);
            console.log('   Current session ID:', session.user.id);
            console.log('\n🔧 SOLUTION: Log out and log back in with petrusenkocorp@gmail.com');
        }
    }
}

async function updatePhoneAssignment(correctUserId) {
    const session = JSON.parse(localStorage.getItem('fixlify-auth-token'));
    
    console.log('\n🔧 Updating phone assignment to user ID:', correctUserId);
    
    // Update the phone
    const updateResponse = await fetch(
        'https://mqppvcrlvsgrsqelglod.supabase.co/rest/v1/telnyx_phone_numbers?phone_number=eq.%2B12898192158',
        {
            method: 'PATCH',
            headers: {
                'Authorization': `Bearer ${session.access_token}`,
                'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1xcHB2Y3JsdnNncnNxZWxnbG9kIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDc1OTE3MDUsImV4cCI6MjA2MzE2NzcwNX0.My-KiqG1bCMqzUru4m59d4v18N3WGxNoNtFPOFAmhzg',
                'Content-Type': 'application/json',
                'Prefer': 'return=representation'
            },
            body: JSON.stringify({
                user_id: correctUserId
            })
        }
    );
    
    if (updateResponse.ok) {
        console.log('✅ Phone successfully assigned to petrusenkocorp@gmail.com!');
    } else {
        console.error('❌ Failed to update:', await updateResponse.text());
    }
}

// Also let's check what account you're actually logged in with
function checkCurrentLogin() {
    const session = JSON.parse(localStorage.getItem('fixlify-auth-token'));
    console.log('\n👤 Current Login Status:');
    console.log('======================');
    if (session && session.user) {
        console.log('Email:', session.user.email);
        console.log('User ID:', session.user.id);
        console.log('\nIf this is NOT petrusenkocorp@gmail.com, you need to:');
        console.log('1. Log out');
        console.log('2. Log back in with petrusenkocorp@gmail.com');
    } else {
        console.log('❌ Not logged in');
    }
}

// Run the checks
console.log('🔍 Checking user accounts and phone assignment...');
checkCurrentLogin();
console.log('\nNow checking phone assignment...');
fixPhoneForCorrectUser();
