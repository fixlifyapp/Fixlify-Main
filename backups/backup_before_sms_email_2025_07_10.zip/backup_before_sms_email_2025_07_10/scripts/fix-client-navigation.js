// fix-client-navigation.js
// Script to fix client navigation issue and test estimate sending

console.log('🚀 Starting fix script...');

// Test sending estimate directly
async function testSendEstimate() {
  console.log('📧 Testing estimate send function...');
  
  // Import Supabase
  const { createClient } = await import('@supabase/supabase-js');
  
  // Get Supabase from window
  const supabase = window.supabase || createClient(
    'https://mqppvcrlvsgrsqelglod.supabase.co',
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1xcHB2Y3JsdnNncnNxZWxnbG9kIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDc1OTE3MDUsImV4cCI6MjA2MzE2NzcwNX0.My-KiqG1bCMqzUru4m59d4v18N3WGxNoNtFPOFAmhzg'
  );
  
  // Get the first estimate to test
  const { data: estimates, error } = await supabase
    .from('estimates')
    .select('*, jobs(*, clients(*))')
    .limit(1);
    
  if (error || !estimates || estimates.length === 0) {
    console.error('❌ No estimates found:', error);
    return;
  }
  
  const estimate = estimates[0];
  const client = estimate.jobs?.clients;
  
  console.log('📋 Found estimate:', {
    id: estimate.id,
    number: estimate.estimate_number,
    clientEmail: client?.email,
    clientName: client?.name
  });
  
  if (!client?.email) {
    console.error('❌ Client email not found');
    return;
  }
  
  // Call send-estimate function
  console.log('📧 Calling send-estimate function...');
  
  try {
    const { data, error: sendError } = await supabase.functions.invoke('send-estimate', {
      body: {
        estimateId: estimate.id,
        recipientEmail: client.email,
        customMessage: 'Test estimate from fix script'
      }
    });
    
    if (sendError) {
      console.error('❌ Send error:', sendError);
      return;
    }
    
    console.log('✅ Send result:', data);
  } catch (err) {
    console.error('❌ Exception:', err);
  }
}

// Fix client navigation
function fixClientNavigation() {
  console.log('🔧 Fixing client navigation...');
  
  // Override navigate function to handle encoded IDs
  const originalNavigate = window.navigate;
  if (originalNavigate) {
    window.navigate = function(path, ...args) {
      if (path && path.includes('/clients/C-')) {
        console.log('🔄 Intercepting client navigation:', path);
        // Extract client ID and ensure it's properly encoded
        const match = path.match(/\/clients\/(C-\d+)/);
        if (match) {
          const clientId = match[1];
          const encodedId = encodeURIComponent(clientId);
          path = path.replace(clientId, encodedId);
          console.log('✅ Fixed path:', path);
        }
      }
      return originalNavigate.call(this, path, ...args);
    };
  }
  
  console.log('✅ Client navigation fix applied');
}

// Run fixes
fixClientNavigation();

// Test estimate sending
console.log('💡 To test estimate sending, run: testSendEstimate()');
window.testSendEstimate = testSendEstimate;

console.log('✅ Fix script loaded. Functions available:');
console.log('- testSendEstimate() - Test sending an estimate email');
