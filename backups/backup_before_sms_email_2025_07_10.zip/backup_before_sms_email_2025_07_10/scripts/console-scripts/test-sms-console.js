// Test script to verify SMS functionality after setting Telnyx API key
// Run this in the browser console after logging into Fixlify

async function testSMS() {
    console.log('🔍 Testing SMS functionality...');
    
    // Get the current user's auth token
    const session = JSON.parse(localStorage.getItem('fixlify-auth-token'));
    if (!session || !session.access_token) {
        console.error('❌ Not logged in! Please log in to Fixlify first.');
        return;
    }
    
    // Prompt for phone number
    const recipientPhone = prompt('Enter recipient phone number (with country code, e.g., +1234567890):');
    if (!recipientPhone) {
        console.log('❌ Test cancelled - no phone number provided');
        return;
    }
    
    const message = 'This is a test SMS from Fixlify to verify the messaging system is working correctly.';
    
    console.log('📱 Sending test SMS to:', recipientPhone);
    
    try {
        const response = await fetch('https://mqppvcrlvsgrsqelglod.supabase.co/functions/v1/telnyx-sms', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${session.access_token}`,
                'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1xcHB2Y3JsdnNncnNxZWxnbG9kIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDc1OTE3MDUsImV4cCI6MjA2MzE2NzcwNX0.My-KiqG1bCMqzUru4m59d4v18N3WGxNoNtFPOFAmhzg'
            },
            body: JSON.stringify({
                recipientPhone: recipientPhone,
                message: message
            })
        });
        
        const result = await response.json();
        
        if (response.ok && result.success) {
            console.log('✅ SMS sent successfully!');
            console.log('📱 From:', result.from);
            console.log('📱 To:', result.to);
            console.log('🆔 Message ID:', result.messageId);
            alert('SMS sent successfully! Check the recipient phone.');
        } else {
            console.error('❌ SMS failed:', result.error);
            alert('SMS failed: ' + result.error);
            
            if (result.error === 'SMS service not configured. Please contact support.') {
                console.log('');
                console.log('🔧 SOLUTION: The TELNYX_API_KEY is not set in Supabase Edge Functions.');
                console.log('');
                console.log('To fix this:');
                console.log('1. Go to https://supabase.com/dashboard/project/mqppvcrlvsgrsqelglod/settings/functions');
                console.log('2. Add a new secret: TELNYX_API_KEY = your_telnyx_api_key');
                console.log('3. Save and try again');
                console.log('');
                console.log('Or run the setup script: setup-telnyx-secrets.ps1');
            }
        }
    } catch (error) {
        console.error('❌ Error sending SMS:', error);
        alert('Error: ' + error.message);
    }
}

// Also check if we have any active phone numbers
async function checkPhoneNumbers() {
    console.log('📞 Checking for active phone numbers...');
    
    const { createClient } = window.supabase;
    const supabase = createClient(
        'https://mqppvcrlvsgrsqelglod.supabase.co',
        'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1xcHB2Y3JsdnNncnNxZWxnbG9kIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDc1OTE3MDUsImV4cCI6MjA2MzE2NzcwNX0.My-KiqG1bCMqzUru4m59d4v18N3WGxNoNtFPOFAmhzg'
    );
    
    const { data: phones, error } = await supabase
        .from('telnyx_phone_numbers')
        .select('*')
        .eq('status', 'active');
    
    if (error) {
        console.error('❌ Error checking phone numbers:', error);
        return;
    }
    
    if (!phones || phones.length === 0) {
        console.log('❌ No active phone numbers found!');
        console.log('You need to set up a Telnyx phone number first.');
    } else {
        console.log('✅ Found', phones.length, 'active phone number(s):');
        phones.forEach(phone => {
            console.log('  📱', phone.phone_number, '- User:', phone.user_id || 'Not assigned');
        });
    }
}

console.log('SMS Test Script Loaded!');
console.log('=======================');
console.log('Run testSMS() to send a test SMS');
console.log('Run checkPhoneNumbers() to see active phone numbers');
console.log('');
console.log('Example: testSMS()');
