// Comprehensive debug script for messaging issues
console.log('🔍 Starting comprehensive messaging system debug...\n');

async function debugMessagingSystem() {
  // Get supabase from window
  const supabase = window.supabase;
  if (!supabase) {
    console.error('❌ Supabase not found on window. Make sure you\'re on the Fixlify app.');
    return;
  }

  // 1. Check authentication
  console.log('1️⃣ Checking authentication...');
  const { data: { user }, error: authError } = await supabase.auth.getUser();
  
  if (authError || !user) {
    console.error('❌ Not authenticated:', authError);
    return;
  }
  
  console.log('✅ Authenticated as:', user.email);
  console.log('   User ID:', user.id);
  
  // 2. Get session token
  console.log('\n2️⃣ Checking session...');
  const { data: { session }, error: sessionError } = await supabase.auth.getSession();
  
  if (sessionError || !session) {
    console.error('❌ No session found:', sessionError);
    return;
  }
  
  console.log('✅ Session token:', session.access_token.substring(0, 20) + '...');
  console.log('   Token expires at:', new Date(session.expires_at * 1000).toLocaleString());
  
  // 3. Check profile
  console.log('\n3️⃣ Checking user profile...');
  const { data: profile, error: profileError } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', user.id)
    .single();
    
  if (profileError) {
    console.error('❌ Error fetching profile:', profileError);
  } else {
    console.log('✅ Profile found:', {
      name: profile.name,
      email: profile.email,
      organization_id: profile.organization_id,
      role: profile.role
    });
  }
  
  // 4. Check Telnyx configuration
  console.log('\n4️⃣ Checking Telnyx phone numbers...');
  const { data: phoneNumbers, error: phoneError } = await supabase
    .from('telnyx_phone_numbers')
    .select('*')
    .or(`user_id.eq.${user.id},user_id.is.null`)
    .eq('status', 'active');
    
  if (phoneError) {
    console.error('❌ Error fetching phone numbers:', phoneError);
  } else {
    console.log('✅ Active phone numbers:', phoneNumbers?.length || 0);
    phoneNumbers?.forEach(phone => {
      console.log(`   - ${phone.phone_number} (user: ${phone.user_id || 'shared'})`);
    });
  }
  
  // 5. Test edge function directly
  console.log('\n5️⃣ Testing edge function invocation...');
  
  // Test a simple edge function call
  try {
    console.log('   Testing telnyx-sms function...');
    const { data, error } = await supabase.functions.invoke('telnyx-sms', {
      body: {
        recipientPhone: '+15551234567',
        message: 'Debug test message',
        client_id: null,
        job_id: null
      }
    });
    
    if (error) {
      console.error('❌ Edge function error:', error);
      console.error('   Error details:', {
        message: error.message,
        details: error.details,
        hint: error.hint,
        code: error.code
      });
    } else {
      console.log('✅ Edge function response:', data);
    }
  } catch (e) {
    console.error('❌ Exception calling edge function:', e);
  }
  
  // 6. Get a sample estimate to test
  console.log('\n6️⃣ Finding test estimate...');
  const { data: estimates, error: estimateError } = await supabase
    .from('estimates')
    .select(`
      *,
      jobs!inner(
        id,
        client_id,
        clients!inner(
          id,
          name,
          email,
          phone
        )
      )
    `)
    .limit(1);
    
  if (estimateError) {
    console.error('❌ Error fetching estimates:', estimateError);
    return;
  }
  
  if (!estimates || estimates.length === 0) {
    console.log('⚠️ No estimates found to test with');
    return;
  }
  
  const testEstimate = estimates[0];
  console.log('✅ Found estimate:', {
    id: testEstimate.id,
    number: testEstimate.estimate_number,
    total: testEstimate.total,
    client: testEstimate.jobs?.clients?.name
  });
  
  // 7. Test send-estimate function
  console.log('\n7️⃣ Testing send-estimate edge function...');
  try {
    const { data, error } = await supabase.functions.invoke('send-estimate', {
      body: {
        estimateId: testEstimate.id,
        recipientEmail: 'test@example.com',
        customMessage: 'Test from debug script'
      }
    });
    
    if (error) {
      console.error('❌ Send estimate error:', error);
      console.error('   Error details:', {
        message: error.message,
        details: error.details,
        hint: error.hint,
        code: error.code
      });
    } else {
      console.log('✅ Send estimate response:', data);
    }
  } catch (e) {
    console.error('❌ Exception sending estimate:', e);
  }
  
  // 8. Test send-estimate-sms function
  console.log('\n8️⃣ Testing send-estimate-sms edge function...');
  try {
    const { data, error } = await supabase.functions.invoke('send-estimate-sms', {
      body: {
        estimateId: testEstimate.id,
        recipientPhone: '+15551234567',
        message: 'Test SMS from debug script'
      }
    });
    
    if (error) {
      console.error('❌ Send estimate SMS error:', error);
      console.error('   Error details:', {
        message: error.message,
        details: error.details,
        hint: error.hint,
        code: error.code
      });
    } else {
      console.log('✅ Send estimate SMS response:', data);
    }
  } catch (e) {
    console.error('❌ Exception sending estimate SMS:', e);
  }
  
  // 9. Check recent communication logs
  console.log('\n9️⃣ Checking recent communication logs...');
  const { data: logs, error: logError } = await supabase
    .from('estimate_communications')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(5);
    
  if (logError) {
    console.error('❌ Error fetching communication logs:', logError);
  } else {
    console.log('✅ Recent communications:', logs?.length || 0);
    logs?.forEach(log => {
      console.log(`   - ${log.communication_type} to ${log.recipient}`);
      console.log(`     Status: ${log.status}, Created: ${new Date(log.created_at).toLocaleString()}`);
    });
  }
  
  console.log('\n✨ Debug complete! Check the errors above for issues.');
}

// Run automatically
debugMessagingSystem();
