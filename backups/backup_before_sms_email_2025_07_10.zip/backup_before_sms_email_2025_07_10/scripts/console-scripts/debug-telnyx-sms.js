// Debug Telnyx SMS Configuration
// Run this in browser console to check Telnyx setup

async function debugTelnyxSMS() {
  const { supabase } = window;
  
  console.log('🔍 Debugging Telnyx SMS Configuration...\n');
  
  // Check authentication
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) {
    console.error('❌ Not authenticated. Please login first.');
    return;
  }
  console.log('✅ Authenticated as:', user.email);
  
  // Check phone numbers
  console.log('\n📱 Checking Telnyx Phone Numbers...');
  const { data: phoneNumbers, error: phoneError } = await supabase
    .from('telnyx_phone_numbers')
    .select('*');
    
  if (phoneError) {
    console.error('❌ Error fetching phone numbers:', phoneError);
  } else if (!phoneNumbers || phoneNumbers.length === 0) {
    console.warn('⚠️ No phone numbers found in telnyx_phone_numbers table');
    console.log('💡 You need to add phone numbers to the table with status="active"');
  } else {
    console.log('📞 Found phone numbers:', phoneNumbers);
    const activeNumbers = phoneNumbers.filter(p => p.status === 'active');
    if (activeNumbers.length === 0) {
      console.warn('⚠️ No active phone numbers found');
      console.log('💡 Set status="active" for at least one phone number');
    } else {
      console.log('✅ Active phone numbers:', activeNumbers.map(p => p.phone_number));
    }
  }
  
  // Test edge function
  console.log('\n🧪 Testing telnyx-sms edge function...');
  try {
    const { data, error } = await supabase.functions.invoke('telnyx-sms', {
      body: {
        recipientPhone: '+1234567890', // Test number
        message: 'Test message from Fixlify debug',
        user_id: user.id,
        metadata: { test: true }
      }
    });
    
    if (error) {
      console.error('❌ Edge function error:', error);
      console.log('💡 Check that TELNYX_API_KEY is set in Supabase dashboard');
    } else if (!data?.success) {
      console.error('❌ SMS send failed:', data);
      console.log('💡 Error details:', data?.error);
    } else {
      console.log('✅ SMS sent successfully:', data);
    }
  } catch (err) {
    console.error('❌ Failed to invoke edge function:', err);
    console.log('💡 Make sure the edge function is deployed');
  }
  
  // Check recent logs
  console.log('\n📋 Recent SMS Communication Logs...');
  const { data: logs } = await supabase
    .from('communication_logs')
    .select('*')
    .eq('communication_type', 'sms')
    .order('created_at', { ascending: false })
    .limit(5);
    
  if (logs && logs.length > 0) {
    console.table(logs.map(l => ({
      recipient: l.recipient,
      status: l.status,
      created: new Date(l.created_at).toLocaleString(),
      error: l.metadata?.error
    })));
  } else {
    console.log('No recent SMS logs found');
  }
  
  console.log('\n📚 Next Steps:');
  console.log('1. Deploy edge functions: supabase functions deploy telnyx-sms');
  console.log('2. Set TELNYX_API_KEY in Supabase dashboard > Edge Functions > Secrets');
  console.log('3. Add active phone numbers to telnyx_phone_numbers table');
  console.log('4. Test with a real phone number');
}

// Run the debug function
debugTelnyxSMS();