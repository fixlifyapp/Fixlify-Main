// SMS System Test Script
// Run this in your browser console (F12) to test SMS functionality

console.clear();
console.log("🔍 SMS SYSTEM DIAGNOSTIC TEST");
console.log("=============================\n");

async function runSMSTest() {
  try {
    // 1. Get current session
    const { data: { session } } = await window.supabase.auth.getSession();
    if (!session) {
      console.error("❌ Not logged in! Please log in first.");
      return;
    }
    
    console.log("✅ Logged in as:", session.user.email);
    console.log("   User ID:", session.user.id);
    
    // 2. Check phone numbers
    console.log("\n📱 Checking phone numbers...");
    const { data: phoneNumbers, error: phoneError } = await window.supabase
      .from('telnyx_phone_numbers')
      .select('*')
      .eq('user_id', session.user.id)
      .eq('status', 'active');
    
    if (phoneError) {
      console.error("❌ Error fetching phone numbers:", phoneError);
      return;
    }
    
    if (phoneNumbers && phoneNumbers.length > 0) {
      console.log("✅ Found active phone number:", phoneNumbers[0].phone_number);
    } else {
      console.error("❌ No active phone numbers found for your user!");
      return;
    }
    
    // 3. Test SMS sending
    console.log("\n📤 Testing SMS send functionality...");
    const testPhone = prompt("Enter a phone number to send test SMS (e.g., +16474242323):", "+1");
    
    if (!testPhone || testPhone === "+1") {
      console.log("⚠️ Test cancelled - no phone number provided");
      return;
    }
    
    console.log("   Sending test SMS to:", testPhone);
    
    const response = await fetch('https://mqppvcrlvsgrsqelglod.supabase.co/functions/v1/telnyx-sms', {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + session.access_token,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        recipientPhone: testPhone,
        message: 'Test SMS from Fixlify - SMS system is working! 🎉',
        client_id: null,
        job_id: null,
        user_id: session.user.id
      })
    });
    
    const result = await response.json();
    console.log("\n📊 Response:", result);
    
    if (result.success) {
      console.log("✅ SMS sent successfully!");
      console.log("   Message ID:", result.messageId);
      console.log("   From:", result.from);
      console.log("   To:", result.to);
      
      // Check if message was logged
      setTimeout(async () => {
        console.log("\n📋 Checking message log...");
        const { data: messages } = await window.supabase
          .from('messages')
          .select('*')
          .eq('message_sid', result.messageId)
          .single();
        
        if (messages) {
          console.log("✅ Message logged in database!");
        } else {
          console.log("⚠️ Message not found in database (might take a moment to appear)");
        }
      }, 2000);
      
    } else {
      console.error("❌ SMS sending failed:", result.error);
      console.log("\n🔧 Troubleshooting tips:");
      
      if (result.error.includes("No active phone number")) {
        console.log("   - No phone number is assigned to your user");
        console.log("   - Check the telnyx_phone_numbers table");
      } else if (result.error.includes("authentication")) {
        console.log("   - Authentication issue - try logging out and back in");
      } else if (result.error.includes("Telnyx")) {
        console.log("   - Telnyx API error - check your Telnyx account");
        console.log("   - Ensure you have SMS credits");
        console.log("   - Verify the phone number format is correct");
      }
    }
    
  } catch (error) {
    console.error("❌ Test failed with error:", error);
    console.log("\n💡 Common issues:");
    console.log("   - Edge function might be down");
    console.log("   - Network connectivity issues");
    console.log("   - Invalid session token");
  }
}

// Also test from an estimate
async function testEstimateSMS() {
  console.log("\n📄 Testing estimate SMS...");
  
  // Get a recent estimate
  const { data: estimates } = await window.supabase
    .from('estimates')
    .select('*, jobs!inner(*, clients!inner(*))')
    .order('created_at', { ascending: false })
    .limit(1);
  
  if (!estimates || estimates.length === 0) {
    console.log("❌ No estimates found to test with");
    return;
  }
  
  const estimate = estimates[0];
  const client = estimate.jobs.clients;
  console.log("   Using estimate:", estimate.estimate_number);
  console.log("   Client:", client.name);
  
  const testPhone = prompt("Enter phone number for estimate SMS:", client.phone || "+1");
  
  if (!testPhone || testPhone === "+1") {
    console.log("⚠️ Test cancelled");
    return;
  }
  
  const { data: { session } } = await window.supabase.auth.getSession();
  
  const response = await fetch('https://mqppvcrlvsgrsqelglod.supabase.co/functions/v1/send-estimate-sms', {
    method: 'POST',
    headers: {
      'Authorization': 'Bearer ' + session.access_token,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      estimateId: estimate.id,
      recipientPhone: testPhone
    })
  });
  
  const result = await response.json();
  console.log("   Result:", result);
  
  if (result.success) {
    console.log("✅ Estimate SMS sent successfully!");
    console.log("   Portal link included:", !!result.portalLink);
  } else {
    console.error("❌ Estimate SMS failed:", result.error);
  }
}

// Run the test
console.log("Starting SMS test...\n");
runSMSTest();

// Make functions available globally
window.testEstimateSMS = testEstimateSMS;
window.runSMSTest = runSMSTest;

console.log("\n💡 Additional tests available:");
console.log("   - testEstimateSMS() - Test sending estimate SMS");
console.log("   - runSMSTest() - Run the basic SMS test again");
