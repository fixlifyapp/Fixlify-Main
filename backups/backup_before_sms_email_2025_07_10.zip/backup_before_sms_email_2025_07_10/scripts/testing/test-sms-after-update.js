// Test SMS after API key update
// Run this in your browser console (F12)

console.clear();
console.log("🚀 Testing SMS with updated Telnyx API key...");
console.log("================================================\n");

async function testSMSNow() {
  try {
    const { data: { session } } = await window.supabase.auth.getSession();
    if (!session) {
      console.error("❌ Not logged in!");
      return;
    }
    
    console.log("✅ Logged in as:", session.user.email);
    
    // Test SMS
    console.log("\n📱 Sending test SMS...");
    
    const testPhone = prompt("Enter phone number to send test SMS to:", "+16474242323");
    if (!testPhone) {
      console.log("❌ Test cancelled");
      return;
    }
    
    const response = await fetch('https://mqppvcrlvsgrsqelglod.supabase.co/functions/v1/telnyx-sms', {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + session.access_token,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        recipientPhone: testPhone,
        message: 'Test SMS from Fixlify - API key updated! 🎉',
        user_id: session.user.id
      })
    });
    
    const result = await response.json();
    
    if (result.success) {
      console.log("✅ SUCCESS! SMS sent!");
      console.log("   Message ID:", result.messageId);
      console.log("   From:", result.from);
      console.log("   To:", result.to);
      console.log("\n🎉 Your SMS system is now working!");
    } else {
      console.error("❌ Still failing:", result.error);
      
      if (result.error.includes("credentials")) {
        console.log("\n⏰ The API key might still be propagating. Wait 2-3 minutes and try again.");
      }
    }
    
  } catch (error) {
    console.error("❌ Error:", error);
  }
}

// Also test an estimate SMS
async function testEstimateSMSNow() {
  try {
    console.log("\n📄 Testing estimate SMS...");
    
    // Get latest estimate
    const { data: estimates } = await window.supabase
      .from('estimates')
      .select('*, jobs!inner(*, clients!inner(*))')
      .order('created_at', { ascending: false })
      .limit(1);
    
    if (!estimates || estimates.length === 0) {
      console.log("❌ No estimates found");
      return;
    }
    
    const estimate = estimates[0];
    console.log("Using estimate:", estimate.estimate_number);
    
    const testPhone = prompt("Enter phone for estimate SMS:", estimate.jobs.clients.phone || "+16474242323");
    if (!testPhone) return;
    
    const { data: { session } } = await window.supabase.auth.getSession();
    
    const response = await fetch('https://mqppvcrlvsgrsqelglod.supabase.co/functions/v1/send-estimate-sms', {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + session.access_token,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        estimateId: estimate.id,
        recipientPhone: testPhone
      })
    });
    
    const result = await response.json();
    
    if (result.success) {
      console.log("✅ Estimate SMS sent successfully!");
      console.log("   Portal link:", result.portalLink);
    } else {
      console.error("❌ Failed:", result.error);
    }
  } catch (error) {
    console.error("Error:", error);
  }
}

// Run the test
console.log("Starting test in 3 seconds (to allow key propagation)...");
setTimeout(() => {
  testSMSNow();
}, 3000);

// Make functions available
window.testSMSNow = testSMSNow;
window.testEstimateSMSNow = testEstimateSMSNow;

console.log("\n💡 Commands available:");
console.log("   testSMSNow() - Test basic SMS");
console.log("   testEstimateSMSNow() - Test estimate SMS with portal link");
