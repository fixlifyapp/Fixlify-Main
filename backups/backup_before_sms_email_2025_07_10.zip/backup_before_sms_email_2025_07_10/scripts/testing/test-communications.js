// Quick test script to verify SMS/Email functionality
// Run this in your browser console on the Fixlify app

// Test 1: Check if edge functions are available
async function testEdgeFunctions() {
  console.log('🧪 Testing Edge Functions...\n');
  
  const functions = [
    'send-email',
    'telnyx-sms', 
    'send-estimate',
    'send-estimate-sms',
    'send-invoice',
    'send-invoice-sms',
    'telnyx-webhook'
  ];
  
  console.log('✅ Available edge functions:');
  functions.forEach(fn => console.log(`  - ${fn}`));
  
  console.log('\n📧 To test sending, use the UI or run:');
  console.log(`await window.supabase.functions.invoke('send-email', {
    body: {
      to: 'test@example.com',
      subject: 'Test Email',
      html: '<h1>Test</h1>',
      text: 'Test email'
    }
  });`);
}

// Test 2: Check authentication
async function testAuth() {
  console.log('\n🔐 Testing Authentication...');
  
  const { data: { user } } = await window.supabase.auth.getUser();
  if (user) {
    console.log('✅ Authenticated as:', user.email);
    console.log('   User ID:', user.id);
  } else {
    console.log('❌ Not authenticated');
  }
}

// Test 3: Check for recent communications
async function testCommunications() {
  console.log('\n💬 Testing Communications...');
  
  const { data: messages, error } = await window.supabase
    .from('messages')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(5);
    
  if (error) {
    console.log('❌ Error fetching messages:', error.message);
  } else {
    console.log(`✅ Found ${messages?.length || 0} recent messages`);
    messages?.forEach(msg => {
      console.log(`  - ${msg.direction}: ${msg.content?.substring(0, 50)}...`);
    });
  }
}

// Run all tests
async function runAllTests() {
  console.log('🚀 Starting Fixlify Communication Tests\n');
  console.log('=====================================\n');
  
  await testEdgeFunctions();
  await testAuth();
  await testCommunications();
  
  console.log('\n=====================================');
  console.log('✅ Tests complete!\n');
  console.log('💡 Next steps:');
  console.log('1. Try sending an estimate/invoice from the Jobs page');
  console.log('2. Check the Messages Center for conversations');
  console.log('3. Configure Telnyx webhook for incoming SMS');
}

// Run the tests
runAllTests();
