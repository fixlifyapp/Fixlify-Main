// Test Telnyx phone number sync after fixing user_id constraint
// Run this in the browser console

async function testTelnyxSync() {
  console.log('🔧 Testing Telnyx sync after database fix...');
  
  try {
    // Get auth token
    const authToken = localStorage.getItem('fixlify-auth-token')?.replace(/['"]/g, '');
    if (!authToken) {
      throw new Error('Not authenticated. Please log in first.');
    }

    console.log('🔄 Calling sync-telnyx-numbers edge function...');
    
    // Call the sync function
    const response = await fetch('https://mqppvcrlvsgrsqelglod.supabase.co/functions/v1/sync-telnyx-numbers', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${authToken}`,
        'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1xcHB2Y3JsdnNncnNxZWxnbG9kIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDc1OTE3MDUsImV4cCI6MjA2MzE2NzcwNX0.My-KiqG1bCMqzUru4m59d4v18N3WGxNoNtFPOFAmhzg'
      },
      body: JSON.stringify({})
    });

    const result = await response.json();
    console.log('📱 Sync response:', result);

    if (!response.ok) {
      throw new Error(result.error || 'Sync failed');
    }

    if (result.success) {
      console.log('✅ Sync successful!');
      console.log(`📊 Synced ${result.synced.total} total numbers`);
      console.log(`➕ Inserted ${result.synced.inserted} new numbers`);
      console.log(`📝 Updated ${result.synced.updated} existing numbers`);
      console.log(`❌ Deactivated ${result.synced.deactivated} removed numbers`);
      
      // Now check the database to see if numbers were added
      console.log('\n🔍 Checking database for phone numbers...');
      
      const dbResponse = await fetch('https://mqppvcrlvsgrsqelglod.supabase.co/rest/v1/telnyx_phone_numbers?select=*', {
        headers: {
          'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1xcHB2Y3JsdnNncnNxZWxnbG9kIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDc1OTE3MDUsImV4cCI6MjA2MzE2NzcwNX0.My-KiqG1bCMqzUru4m59d4v18N3WGxNoNtFPOFAmhzg',
          'Authorization': `Bearer ${authToken}`
        }
      });
      
      const numbers = await dbResponse.json();
      console.log(`\n📱 Found ${numbers.length} phone numbers in database:`);
      numbers.forEach(num => {
        console.log(`  - ${num.phone_number} (${num.status})${num.user_id ? ' [Assigned]' : ' [Available]'}`);
      });
      
      // Refresh the page if on phone management
      if (window.location.pathname.includes('phone')) {
        console.log('\n🔄 Refreshing page to show updated numbers...');
        setTimeout(() => window.location.reload(), 1000);
      }
    }
  } catch (error) {
    console.error('❌ Sync test failed:', error);
    
    // Check if it's an API key issue
    if (error.message.includes('TELNYX_API_KEY')) {
      console.log('\n⚠️ TELNYX_API_KEY not configured in Supabase edge function secrets.');
      console.log('To fix this:');
      console.log('1. Go to https://supabase.com/dashboard/project/mqppvcrlvsgrsqelglod/settings/vault');
      console.log('2. Add a new secret:');
      console.log('   - Name: TELNYX_API_KEY');
      console.log('   - Value: Your Telnyx API key from https://portal.telnyx.com/#/app/account/api-keys');
    }
  }
}

// Auto-run the test
testTelnyxSync();
