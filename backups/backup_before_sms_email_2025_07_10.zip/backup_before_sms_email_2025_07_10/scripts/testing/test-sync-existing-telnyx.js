// Test and Sync Telnyx Numbers - Using Existing API Keys
// This script uses the Telnyx API key already configured in your Supabase

console.log('🔧 Testing your existing Telnyx configuration...\n');

async function testAndSyncTelnyx() {
  try {
    // Check if user is logged in
    const authToken = localStorage.getItem('fixlify-auth-token')?.replace(/['"]/g, '');
    if (!authToken) {
      console.error('❌ You need to be logged in to Fixlify first!');
      return;
    }
    
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      console.error('❌ Could not get user information');
      return;
    }
    
    console.log('✅ Logged in as:', user.email);
    console.log('');
    
    // Step 1: Test Telnyx connection using the edge function
    console.log('📡 Testing Telnyx API connection...');
    
    const testResponse = await fetch('https://mqppvcrlvsgrsqelglod.supabase.co/functions/v1/telnyx-phone-numbers', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${authToken}`,
        'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1xcHB2Y3JsdnNncnNxZWxnbG9kIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDc1OTE3MDUsImV4cCI6MjA2MzE2NzcwNX0.My-KiqG1bCMqzUru4m59d4v18N3WGxNoNtFPOFAmhzg'
      },
      body: JSON.stringify({
        action: 'test_telnyx_connection'
      })
    });
    
    const testResult = await testResponse.json();
    
    if (!testResult.success) {
      console.error('❌ Telnyx API key is not configured or invalid');
      console.log('\nYour Telnyx API key needs to be added to Supabase.');
      console.log('Please ask your admin to add it in Supabase Edge Function secrets.');
      return;
    }
    
    console.log('✅ Telnyx API is configured and working!\n');
    
    // Step 2: Sync numbers from Telnyx
    console.log('🔄 Syncing phone numbers from your Telnyx account...');
    
    const syncResponse = await fetch('https://mqppvcrlvsgrsqelglod.supabase.co/functions/v1/sync-telnyx-numbers', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${authToken}`,
        'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1xcHB2Y3JsdnNncnNxZWxnbG9kIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDc1OTE3MDUsImV4cCI6MjA2MzE2NzcwNX0.My-KiqG1bCMqzUru4m59d4v18N3WGxNoNtFPOFAmhzg'
      },
      body: JSON.stringify({})
    });
    
    const syncResult = await syncResponse.json();
    
    if (syncResult.success) {
      console.log('✅ Sync completed successfully!');
      console.log(`📊 Found ${syncResult.synced.total} numbers in your Telnyx account`);
      console.log(`➕ Added ${syncResult.synced.inserted} new numbers`);
      console.log(`📝 Updated ${syncResult.synced.updated} existing numbers\n`);
    } else {
      console.error('❌ Sync failed:', syncResult.error);
      return;
    }
    
    // Step 3: Show all available numbers
    console.log('📱 Checking phone numbers in your system...\n');
    
    const numbersResponse = await fetch('https://mqppvcrlvsgrsqelglod.supabase.co/rest/v1/telnyx_phone_numbers?select=*&order=phone_number', {
      headers: {
        'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1xcHB2Y3JsdnNncnNxZWxnbG9kIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDc1OTE3MDUsImV4cCI6MjA2MzE2NzcwNX0.My-KiqG1bCMqzUru4m59d4v18N3WGxNoNtFPOFAmhzg',
        'Authorization': `Bearer ${authToken}`
      }
    });
    
    const numbers = await numbersResponse.json();
    
    // Group numbers by status
    const myNumbers = numbers.filter(n => n.user_id === user.id);
    const availableNumbers = numbers.filter(n => !n.user_id);
    const otherNumbers = numbers.filter(n => n.user_id && n.user_id !== user.id);
    
    console.log(`📊 Total numbers: ${numbers.length}`);
    console.log(`✅ Your numbers: ${myNumbers.length}`);
    console.log(`📱 Available to claim: ${availableNumbers.length}`);
    console.log(`👥 Claimed by others: ${otherNumbers.length}\n`);
    
    if (myNumbers.length > 0) {
      console.log('✅ YOUR PHONE NUMBERS:');
      myNumbers.forEach(n => {
        console.log(`   📞 ${n.phone_number} (${n.locality || n.area_code || 'Active'})`);
      });
      console.log('');
    }
    
    if (availableNumbers.length > 0) {
      console.log('📱 AVAILABLE NUMBERS (you can claim these):');
      availableNumbers.forEach(n => {
        console.log(`   📞 ${n.phone_number} (${n.locality || n.area_code || 'Available'})`);
      });
      console.log('');
    }
    
    // Step 4: Auto-claim a number if user has none
    if (myNumbers.length === 0 && availableNumbers.length > 0) {
      console.log('🎯 You don\'t have a phone number yet. Let me claim one for you...\n');
      
      const numberToClaim = availableNumbers[0];
      
      const claimResponse = await fetch(`https://mqppvcrlvsgrsqelglod.supabase.co/rest/v1/telnyx_phone_numbers?id=eq.${numberToClaim.id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1xcHB2Y3JsdnNncnNxZWxnbG9kIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDc1OTE3MDUsImV4cCI6MjA2MzE2NzcwNX0.My-KiqG1bCMqzUru4m59d4v18N3WGxNoNtFPOFAmhzg',
          'Authorization': `Bearer ${authToken}`
        },
        body: JSON.stringify({
          user_id: user.id,
          status: 'active'
        })
      });
      
      if (claimResponse.ok) {
        console.log(`✅ Successfully claimed ${numberToClaim.phone_number} for your account!`);
        console.log('📱 You can now send SMS messages!\n');
      } else {
        console.error('❌ Could not claim number automatically');
      }
    } else if (myNumbers.length > 0) {
      console.log('✅ You already have phone numbers assigned to your account.');
      console.log('📱 You\'re ready to send SMS messages!\n');
    }
    
    // Helper functions
    console.log('💡 HELPFUL COMMANDS:\n');
    
    if (availableNumbers.length > 0) {
      console.log('To claim a different number, use:');
      console.log(`claimNumber("${availableNumbers[0].phone_number}")\n`);
      
      window.claimNumber = async function(phoneNumber) {
        try {
          // Find the number
          const number = numbers.find(n => n.phone_number === phoneNumber);
          if (!number) {
            console.error('❌ Number not found');
            return;
          }
          
          if (number.user_id) {
            console.error('❌ This number is already claimed');
            return;
          }
          
          const response = await fetch(`https://mqppvcrlvsgrsqelglod.supabase.co/rest/v1/telnyx_phone_numbers?id=eq.${number.id}`, {
            method: 'PATCH',
            headers: {
              'Content-Type': 'application/json',
              'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1xcHB2Y3JsdnNncnNxZWxnbG9kIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDc1OTE3MDUsImV4cCI6MjA2MzE2NzcwNX0.My-KiqG1bCMqzUru4m59d4v18N3WGxNoNtFPOFAmhzg',
              'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify({
              user_id: user.id,
              status: 'active'
            })
          });
          
          if (response.ok) {
            console.log(`✅ Successfully claimed ${phoneNumber}!`);
            if (window.location.pathname.includes('phone')) {
              setTimeout(() => window.location.reload(), 1000);
            }
          } else {
            console.error('❌ Failed to claim number');
          }
        } catch (err) {
          console.error('❌ Error:', err.message);
        }
      };
    }
    
    // Test SMS function
    console.log('To test SMS sending:');
    console.log('testSMS("+1234567890", "Your test message")\n');
    
    window.testSMS = async function(toPhone, message) {
      try {
        console.log('📱 Sending test SMS...');
        
        const response = await fetch('https://mqppvcrlvsgrsqelglod.supabase.co/functions/v1/telnyx-sms', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${authToken}`,
            'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1xcHB2Y3JsdnNncnNxZWxnbG9kIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDc1OTE3MDUsImV4cCI6MjA2MzE2NzcwNX0.My-KiqG1bCMqzUru4m59d4v18N3WGxNoNtFPOFAmhzg'
          },
          body: JSON.stringify({
            recipientPhone: toPhone,
            message: message || 'Test message from Fixlify!'
          })
        });
        
        const result = await response.json();
        
        if (result.success) {
          console.log('✅ SMS sent successfully!');
          console.log(`From: ${result.from}`);
          console.log(`To: ${result.to}`);
          console.log(`Message ID: ${result.messageId}`);
        } else {
          console.error('❌ SMS failed:', result.error);
        }
      } catch (err) {
        console.error('❌ Error:', err.message);
      }
    };
    
    console.log('🎉 Setup complete! Your SMS system is ready.\n');
    
    // Refresh if on phone page
    if (window.location.pathname.includes('phone')) {
      console.log('🔄 Refreshing page to show updated numbers...');
      setTimeout(() => window.location.reload(), 2000);
    }
    
  } catch (error) {
    console.error('❌ Error:', error.message);
    console.log('\nTroubleshooting tips:');
    console.log('1. Make sure you are logged in to Fixlify');
    console.log('2. Check that your Telnyx API key is configured in Supabase');
    console.log('3. Verify you have active phone numbers in your Telnyx account');
  }
}

// Run the test and sync
testAndSyncTelnyx();
