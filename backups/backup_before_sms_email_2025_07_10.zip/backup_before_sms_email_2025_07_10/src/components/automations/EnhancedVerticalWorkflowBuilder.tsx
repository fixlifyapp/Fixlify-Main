import React from 'react';

// Temporarily disabled to fix build issues
export const EnhancedVerticalWorkflowBuilder = () => {
  return (
    <div className="p-4 text-center">
      <p>Enhanced Workflow Builder is temporarily unavailable while we fix some technical issues.</p>
    </div>
  );
};

export default EnhancedVerticalWorkflowBuilder;